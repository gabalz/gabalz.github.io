
% Add all subdirectories to the load path.
workpath = [pwd() filesep];

% Define a common library path to search for extensions.
libpath = '/cshome/gbalazs/salient/lib';

addpath([workpath 'util']);
if ~exist('addpathnew')
    error(['Work path is not set correctly: ' workpath '.']);
end
addpathnew([workpath 'cvxreg']);
addpathnew([workpath 'stat']);
addpathnew([workpath 'spp']);
addpathnew([workpath 'spp' filesep 'bb']);
addpathnew([workpath 'spp' filesep 'esp']);

global use_single_thread_optim;
use_single_thread_optim = false;

%------------------------------------------------------------------------------

global is_matlab;
global is_octave;
global system_info;

is_matlab = 0;
system_info = '?';
try
    OCTAVE_VERSION;
    system_info = ['Octave ' OCTAVE_VERSION];
    page_screen_output(0);
    page_output_immediately(1);
    sumsqr = @(x) sumsq(x);
catch
    is_matlab = 1;
    system_info = ['Matlab ' version];
end
is_octave = 1 - is_matlab;

% MOSEK
global is_mosek;
is_mosek = 0;
path_mosek = [libpath '/mosek'];
path_mosek_lic = [path_mosek '/mosek.lic'];
if exist(path_mosek)
    if exist(path_mosek_lic)
        try
            setenv('MOSEKLM_LICENSE_FILE', path_mosek_lic);
            addpathnew([path_mosek '/7/toolbox/r2009b']);
            mosek_quadprog(speye(2), [1;1], speye(2), [2;1]); % fast check
            is_mosek = 1;
        catch
            lasterror
            lasterror.message
            pause(2);
        end
    else
        warning(['No MOSEK license has found at ' path_mosek_lic '!']);
        pause(2);
    end
end
clear path_mosek_lic;
