
function mu = distr_rademacher(d)
%
% d : dimension
% coordinates are independent
%
    mu = distr(d);
    mu.data.name = 'Rademacher';

    if d == 1
        mu.mean = 0;
        mu.std = 1;
    end
    mu.domain = @() [-1; 1];

    mu.sampler = @(n) 2*randi(2, n, d) - 3;
    mu.visual = @(varargin) distr_visual(mu, varargin);
    mu.description = @() rademacher_description(mu);
end

function str = rademacher_description(mu)
    str = mu.data.name;
    if mu.data.d > 1
        str = [str '^' num2str(mu.data.d)];
    end
end
