
function X = randsimplex(n, d)
% X = randsimplex(n, d)
% Generates n samples uniformly from the d dimensional unit simplex.
%
  X = [zeros(n,1), sort(rand(n,d-1), 2), ones(n,1)];
  X = X(:,2:end)-X(:,1:end-1);
end

