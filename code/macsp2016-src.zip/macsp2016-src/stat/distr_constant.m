
function mu = distr_constant(c)
%%% Constant distribution.
%%%
  if size(c,2) > 1, error('Invalid dimension!'); end

  mu = distr(size(c,1));
  mu.data.name = 'constant';
  mu.mean = c;
  mu.std = zeros(size(c));

  mu.domain = @() [c'; c'];

  mu.sampler = @(n) repmat(c', n, 1);
  mu.description = @() mat2str(c);
end
