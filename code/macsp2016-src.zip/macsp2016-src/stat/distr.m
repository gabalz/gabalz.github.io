
function mu = distr(d)
%%%
%%% d : dimension
%%%
  mu = struct();

  mu.data = struct();
  mu.data.d = d;
  if ~isfinite(d) || d < 1 || 0 ~= mod(d,1)
    error(['Invalid dimension: ' num2str(d)]);
  end

  mu.data.name = 'unknown distribution';
  mu.description = @() error('missing description');

  mu.domain = @() error('missing domain');
  mu.sampler = @(n) error('missing sampler');

  mu.mean = nan;
  mu.std = nan;
end
