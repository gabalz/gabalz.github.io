
function mu = distr_trnormal(d, m, s, b, varargin)
%%%
%%% d : dimension
%%% m : mean
%%% s : standard deviation
%%% b : upper bound (scalar or vector of dimension d)
%%% a : upper bound (scalar or vector of dimension d, default = -b)
%%% coordinates are independent
%%%
  mu = distr(d);
  mu.data.name = 'trnormal';
  mu.data.m = m;
  mu.data.s = s;
  if s <= 0
    error(['Invalid std: ' num2str(s)]);
  end
  mu.data.b = b;
  if nargin >= 5
    mu.data.a = varargin{1};
  else
    mu.data.a = -b;
  end
  if max(mu.data.a - mu.data.b) >= 0
    error(['Invalid range: [' num2str(mu.data.a) ':' num2str(mu.data.b) ']']);
  end

  if d > 1
    if size(mu.data.m,1) > 1, mu.data.m = mu.data.m'; end
    if size(mu.data.s,1) > 1, mu.data.s = mu.data.s'; end
    if size(mu.data.a,1) > 1, mu.data.a = mu.data.a'; end
    if size(mu.data.b,1) > 1, mu.data.b = mu.data.b'; end
  else
    alpha = (mu.data.a - mu.data.m) / mu.data.s;
    beta = (mu.data.b - mu.data.m) / mu.data.s;
    Z = normcdf(beta) - normcdf(alpha);

    phialpha = normpdf(alpha);
    phibeta = normpdf(beta);

    mu.mean = mu.data.m + mu.data.s * (phialpha - phibeta) / Z;
    mu.std = mu.data.s * ...
             sqrt(1 + (alpha*phialpha - beta*phibeta) / Z ...
                  - ((phialpha - phibeta) / Z)^2);
  end
  mu.domain = @() [mu.data.a .* ones(1,d); mu.data.b .* ones(1,d)];

  mu.sampler = @(n) trnormal_sampler(mu, n);
  mu.visual = @(varargin) distr_visual(mu, varargin);
  mu.description = @() trnormal_description(mu);
end

function X = trnormal_sampler(mu, n)
%%% Christian P. Robert : Simulation of truncated normal variables,
%%%                       arXiv:0907.4010v1  [stat.CO]  23 Jul 2009
%%%
  d = mu.data.d;
  m = mu.data.m;
  s = mu.data.s;
  a = mu.data.a;
  b = mu.data.b;

  alpha = (a-m)/s;
  beta = (b-m)/s;

  if 0 < alpha
    aa = alpha*alpha;
    rho = @(z) exp((aa-z.*z)/2);
  elseif 0 > b
    bb = beta*beta;
    rho = @(z) exp((bb-z.*z)/2);
  else
    rho = @(z) exp(-z.*z/2);
  end

  ba = beta-alpha;
  nd = n*d;
  X = [];
  while numel(X) < nd
    ndiff = n - numel(X);
    Z = alpha+rand(ndiff,1)*ba;
    i = find(rand(ndiff,1) <= rho(Z));
    X = [X; m + s*Z(i)];
  end
  X = reshape(X, n, d);
end

function str = trnormal_description(mu)
  str = mu.data.name;
  if numel(mu.data.m) == 1 && numel(mu.data.s) == 1
    str = [str '(' num2str(mu.data.m) ',' num2str(mu.data.s)];
  else
    str = [str '(...'];
  end
  if numel(mu.data.a) == 1 && numel(mu.data.b) == 1
    str = [str ',' num2str(mu.data.a) ',' num2str(mu.data.b) ')'];
  else
    str = [str ',...)'];
  end
  if mu.data.d > 1
    str = [str '^' num2str(mu.data.d)];
  end
end
