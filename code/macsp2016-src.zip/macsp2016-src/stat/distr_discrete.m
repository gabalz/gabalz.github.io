
function mu = distr_discrete(vals, probs)
%%%
%%% vals  : values (d x k)
%%% probs : probabilities (d x k)
%%%
  [d,k] = size(vals);
  if size(probs,1) ~= d, error('Invalid row number for probs.'); end
  if size(probs,2) ~= k, error('Invalid column number for probs.'); end

  mu.data.name = 'discrete';
  mu.data.d = d;
  mu.data.k = k;

  mu.data.a = min(vals, [], 2)';
  mu.data.b = max(vals, [], 2)';
  mu.domain = @() [mu.data.a .* ones(1,d); mu.data.b .* ones(1,d)];
  if d == 1
    mu.mean = sum(vals .* probs);
    mu.std = sum(probs .* (vals - mu.mean).^2);
  end

  mu.vals = vals;
  mu.probs = probs;
  mu.cump = cumsum(probs,2);
  if ~isempty(find(abs(mu.cump(:,end) - 1) > sqrt(eps)))
    diff = sum(probs)-1, error('Invalid distribution by probs.');
  end
  mu.cump(:,end) = 1;
  mu.sampler = @(n) discrete_sampler(mu, n);

  mu.visual = @(varargin) distr_visual(mu, varargin);
  mu.description = @() ['discrete(' num2str(d) ',' num2str(k) ')'];
end

function X = discrete_sampler(mu, n)
  d = mu.data.d;
  C = mu.cump;
  V = mu.vals;

  sizeC = size(C);
  d1 = [1:d]';

  U = rand(d, n);
  X = zeros(n, d);
  for i = 1:n
    [~,sub] = max(bsxfun(@minus, C, U(:,i)) >= 0, [], 2);
    ind = sub2ind(sizeC, d1, sub);
    X(i,:) = V(ind)';
  end
end
