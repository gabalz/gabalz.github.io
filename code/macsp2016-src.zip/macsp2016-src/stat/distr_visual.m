
function distr_visual(mu, args)
%
% mu : distr
% args :
%
%    n : number of samples (default: 10000)
%
    n = 10000;
    if isfield(args, 'n')
        n = args.n;
    end

    if mu.data.d == 1
        X = mu.sampler(n);
        hist(X);
        colormap(summer);
    else mu.data.d == 2
        X = mu.sampler(n);
        plot(X(:,1), X(:,2), 'b.', 'MarkerSize', 5);
        xlabel('x_1');
        ylabel('x_2');
    end
end
