
function mu = distr_normal(d, m, s)
%%%
%%% d : dimension
%%% m : mean
%%% s : standard deviation / covariance matrix
%%%
  mu = distr(d);
  mu.data.name = 'normal';
  mu.data.m = m;
  mu.data.s = s;
  mu.data.a = -inf;
  mu.data.b = +inf;
  if min(eig(s)) < 0
    error(['Invalid std: ' mat2str(s)]);
  end

  if d > 1
    if isscalar(mu.data.m)
      mu.data.m = mu.data.m*ones(1,d);
    elseif size(mu.data.m,1) > 1
      mu.data.m = mu.data.m';
    end

    if isscalar(mu.data.s)
      mu.data.s = mu.data.s*eye(d);
    elseif size(mu.data.s,1) == 1 || size(mu.data.s,2) == 1
      mu.data.s = diag(mu.data.s);
    end
  else
    mu.mean = m;
    mu.std = s;
  end
  mu.domain = @() [-inf(1,d); inf(1,d)];

  mu.sampler = @(n) normal_sampler(mu, n);
  mu.visual = @(varargin) distr_visual(mu, varargin);
  mu.description = @() normal_description(mu);
end

function X = normal_sampler(mu, n)
  X = randn(n, mu.data.d);
  X = X * mu.data.s;
  X = bsxfun(@plus, X, mu.data.m);
end

function str = normal_description(mu)
  str = mu.data.name;
  if numel(mu.data.m) == 1 && numel(mu.data.s) == 1
    str = [str '(' num2str(mu.data.m) ',' num2str(mu.data.s) ')'];
  else
    str = [str '(...)'];
  end
  if mu.data.d > 1
    str = [str '^' num2str(mu.data.d)];
  end
end
