
function mu = distr_ring(d, c, r, R)
%
% d : dimension
% c : center
% r : small radius
% R : large radius
% coordinates are independent
%
    mu = distr(d);
    mu.data.name = 'ring';
    mu.data.c = c;
    mu.data.r = r;
    mu.data.R = R;
    if (r >= R)
        error(['Invalid support: (' num2str(r) ',' num2str(R) ')']);
    end

    if d > 1
        if size(mu.data.c,1) > 1, mu.data.c = mu.data.c'; end
    else
        mu.mean = c;
        mu.std = sqrt((R*R + r*R + r*r) / 3);
    end
    mu.domain = @() [c-R; c+R];

    mu.sampler = @(n) ring_sampler(mu, n);
    mu.visual = @(varargin) distr_visual(mu, varargin);
    mu.description = @() ring_description(mu);
end

function X = ring_sampler(mu, n)
% rejection sampling
%
    d = mu.data.d;
    c = mu.data.c;
    r = mu.data.r;
    R = mu.data.R;
    if r >= R
        error(['Invalid range: [' num2str(r) ':' num2str(R) ']']);
    end

    rr = r*r;
    RR = R*R;

    X = (2*rand(n, d)-1)*R;
    norms = sum(X.^2, 2);
    i = find(norms > RR);
    i = [i; find(norms < rr)];
    X(i,:) = [];
    while size(X,1) < n
        ndiff = n - size(X,1);
        nnew = max(ndiff, 1000);
        Xnew = (2*rand(nnew, d)-1)*R;

        norms = sum(Xnew.^2, 2);
        i = find(norms >= rr);
        i = i(find(norms(i) <= RR));
        Xnew = Xnew(i,:);

        if isempty(Xnew), continue; end
        X = [X; Xnew(1:min(size(Xnew,1),ndiff),:)];
    end
    X = bsxfun(@plus, X, c);
end

function str = ring_description(mu)
    str = mu.data.name;
    if numel(mu.data.c) == 1
        str = [str '(' num2str(mu.data.c)];
    else
        str = [str '(...'];
    end
    if numel(mu.data.r) == 1 && numel(mu.data.R) == 1
        str = [str ',' num2str(mu.data.r) ',' num2str(mu.data.R) ')'];
    else
        str = [str ',...)'];
    end
    if mu.data.d > 1
        str = [str '^' num2str(mu.data.d)];
    end
end
