
function mu = distr_discrete_trnormal1(acc, m, s, b, varargin)
%%% Discretized 1-dimensional truncated normal distribution.
%%%
%%% acc : accuracy (> 1 integer)
%%% m   : mean
%%% s   : standard deviation
%%% b   : upper bound
%%% a   : lower bound
%%%
  tol = 2^-20;
  assert (acc > 0);

  a = -b;
  if nargin >= 4
    a = varargin{1};
  end
  assert (a < b);

  ints = a:acc:b;
  vals = (ints(1:end-1) + ints(2:end))/2;

  beta = (b-m)/s;
  alpha = (a-m)/s;
  Z = normcdf(beta) - normcdf(alpha);
  normints = normcdf((ints-m)/s);
  probs = (normints(2:end) - normints(1:end-1)) / Z;

  i = find(probs < tol);
  vals(i) = [];
  probs(i) = [];
  probs = probs / sum(probs);

  mu = distr_discrete(vals, probs);
  mu.data.m = m;
  mu.data.s = s;
  mu.data.a = a;
  mu.data.b = b;
end
