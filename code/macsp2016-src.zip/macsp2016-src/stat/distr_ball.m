
function mu = distr_ring(d, c, R)
%
% d : dimension
% c : center
% R : radius
%
    mu = distr(d);
    mu.data.name = 'ball';
    mu.data.c = c;
    mu.data.R = R;

    if d > 1
        if size(mu.data.c,1) > 1, mu.data.c = mu.data.c'; end
    end
    mu.sampler = @(n) ball_sampler(mu, n);
    mu.visual = @(varargin) distr_visual(mu, varargin);
    mu.description = @() ball_description(mu);
end

function X = ball_sampler(mu, n)
    d = mu.data.d;
    c = mu.data.c;
    R = mu.data.R;

    X = randn(n,d);
    X = bsxfun(@times, X, R./sqrt(sum(X.^2,2)));
    X = bsxfun(@plus, X, c);
end

function str = ball_description(mu)
    str = mu.data.name;
    if numel(mu.data.c) == 1
        str = [str '(' num2str(mu.data.c)];
    else
        str = [str '(...'];
    end
    if numel(mu.data.R) == 1
        str = [str ',' num2str(mu.data.R) ')'];
    else
        str = [str ',...)'];
    end
    if mu.data.d > 1
        str = [str '^' num2str(mu.data.d)];
    end
end
