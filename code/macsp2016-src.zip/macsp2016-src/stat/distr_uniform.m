
function mu = distr_uniform(d, b, varargin)
%%%
%%% d : dimension
%%% b : upper bound (scalar or vector of dimension d)
%%% a : lower bound (scalar or vector of dimension d, default = -b)
%%% coordinates are independent
%%%
  mu = distr(d);
  mu.data.name = 'uniform';
  mu.data.b = b;
  if nargin >= 3
    mu.data.a = varargin{1};
  else
    mu.data.a = -b;
  end
  if max(mu.data.a - mu.data.b) >= 0
    error(['Invalid range: [' num2str(mu.data.a) ...
           ':' num2str(mu.data.b) ']']);
  end

  if d > 1
    if size(mu.data.a,1) > 1, mu.data.a = mu.data.a'; end
    if size(mu.data.b,1) > 1, mu.data.b = mu.data.b'; end
  else % d == 1
    mu.mean = (mu.data.a + mu.data.b) / 2;
    mu.std = (mu.data.b - mu.data.a) / (2*sqrt(3));
  end
  mu.domain = @() [mu.data.a .* ones(1,d); mu.data.b .* ones(1,d)];

  mu.sampler = @(n) uniform_sampler(mu, n);
  mu.visual = @(varargin) distr_visual(mu, varargin);
  mu.description = @() uniform_description(mu);
end

function X = uniform_sampler(mu, n)
  X = rand(n, mu.data.d);
  X = bsxfun(@times, X, mu.data.b - mu.data.a);
  X = bsxfun(@plus, X, mu.data.a);
end

function str = uniform_description(mu)
  str = mu.data.name;
  if numel(mu.data.a) == 1 && numel(mu.data.b) == 1
    str = [str '(' num2str(mu.data.a) ',' num2str(mu.data.b) ')'];
  else
    str = [str '(...)'];
  end
  if mu.data.d > 1
    str = [str '^' num2str(mu.data.d)];
  end
end
