
function mu = distr_beta(d, alpha, beta, b, varargin)
%
% d     : dimension
% alpha : alpha parameter (scalar or vector of dimension d)
% beta  : beta parameter (scalar or vector of dimension d)
% b : upper bound (scalar or vector of dimension d)
% a : upper bound (scalar or vector of dimension d, default = -b)
% coordinates are independent
%
    mu = distr(d);
    mu.data.name = 'beta';
    mu.data.d = d;
    mu.data.alpha = alpha;
    if alpha <= 0
        error(['Invalid alpha: ' num2str(alpha)]);
    end
    mu.data.beta = beta;
    if beta <= 0
        error(['Invalid beta: ' num2str(beta)]);
    end
    mu.data.b = b;
    if nargin >= 5
        mu.data.a = varargin{1};
    else
        mu.data.a = -b;
    end
    if max(mu.data.a - mu.data.b) >= 0
        error(['Invalid range: [' num2str(mu.data.a) ...
               ':' num2str(mu.data.b) ']']);
    end

    if d > 1
        if size(mu.data.alpha,1) > 1, mu.data.alpha = mu.data.alpha'; end
        if size(mu.data.beta,1) > 1, mu.data.beta = mu.data.beta'; end
        if size(mu.data.a,1) > 1, mu.data.a = mu.data.a'; end
        if size(mu.data.b,1) > 1, mu.data.b = mu.data.b'; end
    else
        ba = mu.data.b - mu.data.a;
        mu.mean = mu.data.a + ba*alpha / (alpha + beta);
        mu.std = ba * sqrt(alpha*beta / ((alpha+beta)^2 * (alpha + beta + 1)));
    end
    mu.domain = @() [mu.data.a .* ones(1,d); mu.data.b .* ones(1,d)];

    mu.sampler = @(n) beta_sampler(mu, n);
    mu.visual = @(varargin) distr_visual(mu, varargin);
    mu.description = @() beta_description(mu);
end

function X = beta_sampler(mu, n)
    alpha = mu.data.alpha;
    beta = mu.data.beta;
    a = mu.data.a;
    b = mu.data.b;

    X = betarnd(repmat(alpha, n, 1), repmat(beta, n, 1));
    X = bsxfun(@times, X, b-a);
    X = bsxfun(@plus, X, a);
end

function str = beta_description(mu)
    str = mu.data.name;
    if numel(mu.data.alpha) == 1 && numel(mu.data.beta) == 1
        str = [str '(' num2str(mu.data.alpha) ',' num2str(mu.data.beta)];
    else
        str = [str '(...'];
    end
    if numel(mu.data.a) == 1 && numel(mu.data.b) == 1
        str = [str ',' num2str(mu.data.a) ',' num2str(mu.data.b) ')'];
    else
        str = [str ',...)'];
    end
    if mu.data.d > 1
        str = [str '^' num2str(mu.data.d)];
    end
end
