
function seed = rng_set_seed(varargin)
% Set the random seed.
    global is_matlab;
    limit = 1e8;

    if nargin >= 1
        seed = varargin{1};
    else
        seed = randi(limit);
    end

    if is_matlab
        reset(RandStream.getDefaultStream, seed);
    else
        rand('state', seed);
        randn('state', randi(limit));
        rande('state', randi(limit));
        randg('state', randi(limit));
        randp('state', randi(limit));
    end
end
