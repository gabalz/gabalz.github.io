
function prb = qcqp_update_beq(prb, idx, value)
  if prb.nqc > 0
    idx = idx + prb.nqc;
  end
  prb.blc(idx) = value;
  prb.buc(idx) = value;
end
