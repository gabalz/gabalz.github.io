
function prb = qcqp_update(prb, A, b, varargin)
%%% prb = qcqp_update(prb,A,b)
%%% prb = qcqp_update(prb,A,b,Aeq,beq)
%%% prb = qcqp_update(prb,A,b,Aeq,beq,lb,ub)
%%% prb = qcqp_update(prb,A,b,Aeq,beq,lb,ub,x0)
%%%
%%% Add constraints and update initial point for a QCQP problem.
%%% A,b,Aeq,beq are augmented, lb,ub,x0 are overwritten.
%%%
%%% See: help qcqp_init
%%%
  global is_mosek;
  if ~is_mosek, error('MOSEK is not available.'); end

  if ~isempty(A)
    if isempty(b), error('Empty b for nonempty A!'); end
    prb.a = [prb.a; A];
    prb.blc = [prb.blc; -inf(numel(b),1)];
    prb.buc = [prb.buc; b];
  end

  if nargin >= 5
    Aeq = varargin{1};
    if ~isempty(Aeq)
      beq = varargin{2};
      neq = prb.neq;
      if isempty(beq), error('Empty beq for nonempty Aeq!'); end
      prb.a = [prb.a(1:neq,:); Aeq; prb.a(neq+1:end,:)];
      prb.blc = [prb.blc(1:neq); beq; prb.blc(neq+1:end)];
      prb.buc = [prb.buc(1:neq); beq; prb.buc(neq+1:end)];
      prb.neq = neq + numel(beq);
    end
  end

  if nargin >= 6
    lb = varargin{3};
    if ~isempty(lb)
      prb.blx = full(lb);
    end
  end

  if nargin >= 7
    ub = varargin{4};
    if ~isempty(ub)
      prb.bux = full(ub);
    end
  end

  if nargin >= 8
    x0 = varargin{5};
    if ~isempty(x0)
      prb.sol.itr.xx = full(x0);
    end
  end
end
