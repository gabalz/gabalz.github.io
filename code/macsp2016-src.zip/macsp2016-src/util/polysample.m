
function X = polysample(A, b, lb, ub, x0, nsamples, nskip, varargin)
%%% Hit-and-run sampling for polyhedrons.
%%%
  tol = 1e-6;

  bndratio = 0;
  if nargin >= 8
    bndratio = varargin{1};
  end

  %% Preprocessing.

  dim = numel(x0);
  X = zeros(nsamples, dim);

  i = find(x0 < lb-tol);
  if ~isempty(i)
    i = i(1);
    error(['Infeasible x0, (x0-lb)(' num2str(i) ') = ' num2str(x0(i)-lb(i)) '!']);
  end
  x0 = max(lb,x0);

  i = find(x0 > ub+tol);
  if ~isempty(i)
    i = i(1);
    error(['Infeasible x0, (x0-ub)(' num2str(i) ') = ' num2str(x0(i)-ub(i)) '!']);
  end
  x0 = min(x0,ub);

  [map, idx, val, dim, A, b, lb, ub] = polyfilter(dim, A, b, lb, ub, tol);
  X(:,idx) = repmat(val', nsamples, 1);
  x = x0(map);
  bAx = b-A*x;
  lx = lb-x;
  ux = ub-x;

  i = find(bAx < -tol);
  if ~isempty(i)
    error(['Infeasible x0, (b-A*x0)(' num2str(i) ') = ' num2str(bAx(map(i))) '!']);
  end

  %% Hit-and-run sampling.

  nskp = 0;
  ngen = 0;
  while ngen < nsamples
    dir = randn(dim,1);
    dir = dir / norm(dir);

    cmin = -inf;
    cmax = +inf;

    Adir = A*dir;
    p = find(Adir > 0);
    if ~isempty(p)
      cmax = min(cmax, min(bAx(p) ./ Adir(p)));
    end
    p = find(Adir < 0);
    if ~isempty(p)
      cmin = max(cmin, max(bAx(p) ./ Adir(p)));
    end

    p = find(dir > 0);
    if ~isempty(p)
      dirp = dir(p);
      cmax = min(cmax, min(ux(p) ./ dirp));
      cmin = max(cmin, max(lx(p) ./ dirp));
    end
    p = find(dir < 0);
    if ~isempty(p)
      dirp = dir(p);
      cmax = min(cmax, min(lx(p) ./ dirp));
      cmin = max(cmin, max(ux(p) ./ dirp));
    end

    if cmin > cmax-tol, continue; end

    c = cmin + rand*(cmax-cmin);
    xnew = x + c*dir;
    bAx = b-A*xnew;
    lx = lb-xnew;
    ux = ub-xnew;

    if nskp < nskip
      nskp = nskp + 1;
    else
      ngen = ngen + 1;
      if bndratio > 0 && rand < bndratio
        if rand < 0.5
          c = cmin;
        else
          c = cmax;
        end
      end
      X(ngen,map) = x + c*dir;
    end
    x = xnew;
  end
end

function [map, idx, val, dim, A, b, lb, ub] = polyfilter(dim, A, b, lb, ub, tol)
  idx = [];
  map = [1:dim]';
  val = [];

  if ~isempty(lb) && ~isempty(ub)
    idx = [idx; find(ub <= lb+tol)];
    val = [val; 0.5*(lb(idx)+ub(idx))];
    map = setdiff(map, idx);
    dim = dim - numel(idx);
    b = b - A(:,idx)*val;
    A(:,idx) = [];
    lb(idx) = [];
    ub(idx) = [];
  end

  isElim = true;
  while isElim && numel(map) > 1
    isElim = false;

    for i = 1:numel(b)
      Ai = A(i,:);

      if isempty(find(abs(Ai) > tol))
        A(i,:) = [];
        b(i) = [];
        isElim = true;
        break;
      end

      z = zeros(dim,1);
      p = find(Ai > 0);
      z(p) = lb(p);
      p = find(Ai < 0);
      z(p) = ub(p);

      if Ai*z > b(i)-tol
        j = find(Ai)';
        zj = z(j);
        val = [val; zj];
        b = b - A(:,j)*zj;
        A(:,j) = [];
        lb(j) = [];
        ub(j) = [];
        j = map(j);
        idx = [idx; j];
        map = setdiff(map, j);
        dim = dim - numel(j);
        isElim = true;
        break;
      end
    end
  end
end

