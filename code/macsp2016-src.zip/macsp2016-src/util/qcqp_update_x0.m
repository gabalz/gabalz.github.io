
function prb = qcqp_update_x0(prb, idx, value, params)
  if isempty(idx)
    if params.MSK_IPAR_OPTIMIZER == 1
      prb.sol.itr = value;
    else
      prb.sol.bas = value;
    end
  else
    prb.sol.itr.xx(idx) = value;
  end
end
