
function prb = qcqp_update_ub(prb, idx, value, varargin)
  if nargin > 3 && varargin{1}
    prb.bux(idx) = min(prb.bux(idx), value);
  else
    prb.bux(idx) = value;
  end
end
