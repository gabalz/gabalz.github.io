
function fprint_struct_fields(fid, strct, tab)
  if iscell(strct), return; end
  fields = fieldnames(strct);
  if isempty(fields), return; end

  fmt = [tab '%' num2str(max(cellfun(@length,fields,'uni',true))) 's : %s\n'];
  for fi = 1:numel(fields)
    field = fields{fi};
    value = getfield(strct, field);
    try
      if ~ischar(value)
        if isscalar(value)
          value = num2str(value);
        elseif ismatrix(value)
          value = mat2str(value);
        end
      end
      fprintf(fid, fmt, field, value);
    catch exception
      fmt
      field
      value
      warning(exception);
    end
  end
end

