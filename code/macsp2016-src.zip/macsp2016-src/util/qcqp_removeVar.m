
function prb = qcqp_removeVar(prb, idx)
%%% prb = qcqp_removeVar(prb, idx)
%%%
%%% Remove variables related to indices in idx.
%%%
  if isfield(prb, 'qosubi')
    error('Not supported!');
  end
  prb.c(idx) = [];
  prb.a(:,idx) = [];

  if isfield(prb, 'blx')
    prb.blx(idx) = [];
  end
  if isfield(prb, 'bux')
    prb.bux(idx) = [];
  end
  if isfield(prb, 'sol')
    prb.sol.itr.xx(idx) = [];
  end
end
