
function ts = timestamp(varargin)
%%% Return a yyyy-mm-dd hh:mm:ss formatted timestamp based on clock().
%%%
%%% timestamp()
%%% timestamp('compact')
%%% timestamp('readable-data-only')
%%% timestamp('readable-time-only')
%%% timestamp('compact-date-only')
%%% timestamp('compact-time-only')
%%%
    fmt = 'readable';
    if nargin >= 1
        fmt = lower(varargin{1});
    end

    t = floor(clock());
    if strcmp(fmt,'readable')
        ts = sprintf('%4d-%02d-%02d %02d:%02d:%02d', ...
                     t(1), t(2), t(3), t(4), t(5), t(6));
    elseif strcmp(fmt,'compact')
        ts = sprintf('%4d%02d%02d-%02d%02d%02d', ...
                     t(1), t(2), t(3), t(4), t(5), t(6));
    elseif strcmp(fmt,'readable-date-only')
        ts = sprintf('%4d-%02d-%02d', t(1), t(2), t(3));
    elseif strcmp(fmt,'readable-time-only')
        ts = sprintf('%02d:%02d:%02d', t(4), t(5), t(6));
    elseif strcmp(fmt,'compact-date-only')
        ts = sprintf('%4d%02d%02d', t(1), t(2), t(3));
    elseif strcmp(fmt,'compact-time-only')
        ts = sprintf('%02d%02d%02d', t(4), t(5), t(6));
    else
        error(['Unknown timestamp format: ' fmt]);
    end
end
