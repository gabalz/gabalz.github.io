
function prb = qcqp_removeA(prb, idx)
%%% prb = qcqp_removeA(prb, idx)
%%%
%%% Remove A constraints related to indices in idx.
%%%
  if prb.nqc > 0
    idx = idx + prb.nqc;
  end
  if prb.neq > 0
    idx = idx + prb.neq;
  end
  prb.a(idx,:) = [];
  prb.blc(idx) = [];
  prb.buc(idx) = [];
end
