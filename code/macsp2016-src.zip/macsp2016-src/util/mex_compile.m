
function mex_compile(file, varargin)
    global is_matlab;

    eflags = '';
    if nargin >= 2
      eflags = varargin{1};
    end

    lflags = '';
    if nargin >= 3
      lflags = varargin{2};
    end

    cflags = ['-Wall -O2 -fPIC -std=c99 ' eflags];
    if is_matlab
        cflags = [cflags ' -DFS_MATLAB'];
    end

    if is_matlab
        cmd_mex = ['mex CFLAGS=''$CFLAGS ' cflags '''' ...
                   ' -o ' file ' -lm -largeArrayDims ' lflags ...
                   ' ' file '.c'];
        eval(cmd_mex);
        clear cmd_mex;
    else % octave
        env_cflags = eval('mkoctfile -p CFLAGS');
        setenv('CFLAGS', [strtrim(env_cflags) ' ' cflags]);
        eval(['mex -o ' file ' -lm ' file '.c']);
        setenv('CFLAGS', env_cflags);
    end

    if exist([file '.o'])
        delete([file '.o']);
    end
end
