
function prb = qcqp_update_f(prb, idx, value)
  prb.c(idx) = value;
end
