
function A = qcqp_get_A(prb, rows)
%%% A = qcqp_get_A(prb, rows)
%%%
%%% Return a submatrix of A related to rows.
%%%
  if prb.nqc > 0
    rows = rows + prb.nqc;
  end
  if prb.neq > 0
    rows = rows + prb.neq;
  end
  A = prb.a(rows,:);
end

