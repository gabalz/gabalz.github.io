
function [x, niter, lambda] = solveTRSP(Q, s, g, L, varargin)
%%% x = solveTRSP(Q, s, f, L)
%%% x = solveTRSP(Q, s, f, L, maxniter)
%%% x = solveTRSP(Q, s, f, L, maxniter, tol)
%%%
%%% Solving the trust-region subproblem:
%%%
%%%   min 0.5*x'*Q*diag(s)*Q'*x + g'*x  s.t.  norm(x) <= L
%%%
%%% Q is orthogonal and s is nonnegative.
%%%
%%% See: J. Nocedal, S. J. Wright : Numerical Optimization (2006), Algorithm 4.3
%%%
  maxniter = 100;
  tol = 2e-8;
  if nargin >= 5
    maxniter = varargin{1};
    if nargin >= 6
      tol = varargin{2};
    end
  end

  Qg = -(Q'*g);
  s = max(s, tol);
  x = Q*(Qg./s);
  if isempty(L) || norm(x) <= L
    niter = 0;
    lambda = 0;
    return;
  end

  lambda = 1;
  for niter = 1:maxniter
    drec = 1./(s+lambda);
    y = drec.*Qg;
    x = Q*y;
    y = y.*sqrt(drec);

    xnorm = norm(x);
    if abs(xnorm-L) <= tol, break; end

    lambda = lambda + (xnorm*xnorm/sum(y.^2))*(xnorm-L)/L;
  end
  x = x * (L/xnorm);
end
