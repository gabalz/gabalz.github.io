
function plan_result_concat(datadir, chunks)
%%% E.g.: plan_result_concat('dir', 1:5)
%%%
  if ~strcmp(datadir(end), filesep)
    datadir = [datadir filesep];
  end

  ndms = [];
  spec = [];
  spp_t1 = [];
  spp_T = [];
  spp_pname = [];
  dmi_names = {};

  result = {};
  for c = chunks
    rfile = [datadir sprintf('result-%02d.mat', c)];
    rec = load(rfile);

    if isempty(ndms)
      ndms = rec.ndms;
      spec = rec.spec;
      if isfield(spec, 'repchunk'), spec = rmfield(spec, 'repchunk'); end
      spp_t1 = rec.spp_t1;
      spp_T = rec.spp_T;
      spp_pname = rec.spp_pname;
    else
      if ndms ~= rec.ndms, error('ndms mismatch!'); end
      if spp_t1 ~= rec.spp_t1, error('spp_t1 mismatch!'); end
      if spp_T ~= rec.spp_T, error('spp_T mismatch!'); end
      if ~strcmp(spp_pname, rec.spp_pname), error('spp_pname mismatch!'); end
    end
    if isfield(rec, 'dmi_names')
      if ~isempty(dmi_names), error('multiple dmi_names!'); end
      dmi_names = rec.dmi_names;
    end

    if numel(result) < numel(rec.result)
      result{size(rec.result,1),size(rec.result,2)} = {};
    end
    idx = find(~cellfun(@isempty, rec.result));
    result(idx) = rec.result(idx);
  end

  save([datadir 'result.mat'], '-v7', 'dmi_names', ...
       'ndms', 'spec', 'spp_t1', 'spp_T', 'spp_pname', 'result');

  resultSPPtxt([datadir 'result.txt'], ...
               spec, spp_pname, spp_t1, spp_T, dmi_names, result);
end

