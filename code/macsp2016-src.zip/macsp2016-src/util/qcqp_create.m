
function prb = qcqp_create(H, f, A, b, varargin)
%%% prb = qcqp_create(H,f,A,b)
%%% prb = qcqp_create(H,f,A,b,Aeq,beq)
%%% prb = qcqp_create(H,f,A,b,Aeq,beq,lb,ub)
%%% prb = qcqp_create(H,f,A,b,Aeq,beq,lb,ub,x0)
%%% prb = qcqp_create(H,f,A,b,Aeq,beq,lb,ub,x0,Q,G,c)
%%%
%%% Create a QCQP problem:
%%%
%%%    min 0.5*x'*H*x + f'*x  s.t.  A*x <= b, Aeq*x = beq, lb <= x <= ub,
%%%     x
%%%         0.5*x'*Q{k}*x + G(k,:)*x <= c(k), k = 1,...,numel(Q).
%%%
  global is_mosek;
  if ~is_mosek, error('MOSEK is not available.'); end

  nvars = numel(f);

  %% http://docs.mosek.com/7.0/toolbox/Command_reference.html
  prb = struct();
  if ~isempty(H)
    [prb.qosubi, prb.qosubj, prb.qoval] = find(sparse(tril(H)));
  end
  prb.c = full(f);

  prb.a = zeros(0,nvars);
  prb.blc = zeros(0,1);
  prb.buc = zeros(0,1);

  prb.nqc = 0;
  Q = []; G = []; c = [];
  if nargin >= 12,
    Q = varargin{6};
    G = varargin{7};
    c = varargin{8};

    if ~isempty(Q)
      G = varargin{7};
      if isempty(G), error('Empty G for nonempty Q!'); end
      c = varargin{8};
      if isempty(c), error('Empty c for nonempty Q!'); end

      qcsubk = []; qcsubi = []; qcsubj = []; qcval = [];
      for k = 1:numel(Q)
        [qcsubi_, qcsubj_, qcval_] = find(sparse(tril(Q{k})));
        qcsubk = [qcsubk; ones(numel(qcsubi_),1)*k]; % qc index
        qcsubi = [qcsubi; qcsubi_];
        qcsubj = [qcsubj; qcsubj_];
        qcval = [qcval; qcval_];
      end
      prb.qcsubk = qcsubk;
      prb.qcsubi = qcsubi;
      prb.qcsubj = qcsubj;
      prb.qcval = qcval;
    end
    prb.nqc = numel(c);
    if ~isempty(G), prb.a = G; end
    prb.blc = -inf(prb.nqc,1);
    prb.buc = c;
  end

  prb.neq = 0;
  nargs = numel(varargin);
  prb = qcqp_update(prb, A, b, varargin{1:min(5,nargs)});
end
