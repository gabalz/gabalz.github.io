
function b = addpathnew(p)
% Adds the specified path to the path list if the path exists on the disk
% and is not in the path list yet.
%
% Input:
%   p : the path to be added
%
% Output:
%   b : 1 if the path exists on the disk, 0 otherwise

    global path;

    b = exist(p);
    if b && isempty(findstr(p, path))
        addpath(p);
    end
end

