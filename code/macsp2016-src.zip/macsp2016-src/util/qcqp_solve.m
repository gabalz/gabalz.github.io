
function [xsol, flag, info] = qcqp_solve(prb, varargin)
%%% [xsol,fsol,flag,info] = qcqp_solve(prb)
%%%
%%% Solve a QCQP problem.
%%%
%%% Return flags:
%%%
%%%   0 : ok
%%%  -1 : infeasible
%%%
%%% See: help qcqp_create
%%%
  global use_single_thread_optim;
  global is_mosek;
  if ~is_mosek, error('MOSEK is not available.'); end

  %% MOSEK code query:
  %% [~,res] = mosekopt('symbcon'); getfield(res.symbcon,'MSK_PARAM_NAME')

  if nargin >= 2
    param = varargin{1};
  else
    param = struct();
    param.MSK_IPAR_OPTIMIZER = 1; % MSK_OPTIMIZER_INTPNT
    %param.MSK_IPAR_OPTIMIZER = 3; % MSK_OPTIMIZER_PRIMAL_SIMPLEX
    %param.MSK_IPAR_OPTIMIZER = 4; % MSK_OPTIMIZER_DUAL_SIMPLEX
    %param.MSK_IPAR_OPTIMIZER = 5; % MSK_OPTIMIZER_PRIMAL_DUAL_SIMPLEX
    %param.MSK_IPAR_OPTIMIZER = 6; % MSK_OPTIMIZER_FREE_SIMPLEX
    if param.MSK_IPAR_OPTIMIZER == 1
      param.MSK_IPAR_INTPNT_MAX_ITERATIONS = 10000;
      %param.MSK_IPAR_INTPNT_BASIS = 0; % MSK_OFF
    end
  end
  if use_single_thread_optim
    param.MSK_IPAR_NUM_THREADS = 1; % use a single thread
  end

  %% rcode: http://docs.mosek.com/6.0/toolbox/node022.html#279719592
  [rcode, res] = mosekopt('minimize echo(0) statuskeys(1)', prb, param);

  xsol = [];
  info = [];
  flag = nan;
  if nargout >= 3
    info.flag = flag;
    info.rcode = rcode;
  end

  itr = [];
  bas = [];
  if isfield(res, 'sol')
    if isfield(res.sol, 'itr')
      itr = res.sol.itr;
      solsta = itr.solsta;
    elseif isfield(res.sol, 'bas')
      bas = res.sol.bas;
      solsta = bas.solsta;
    end
  end

  if (rcode == 0 && solsta == 5) || ...
     (rcode == 0 && solsta == 6) % infeasible
    flag = -1;
    if nargout >= 3
      if ~isempty(itr)
        info.sol = itr;
      else
        info.sol = bas;
      end
    end
  elseif isfield(res,'sol') && ...
         (rcode == 10006 || ... % MSK_RES_TRM_STALL
          rcode == 10000 || ... % MSK_RES_TRM_MAX_ITERATIONS
          rcode == 10020 || ... % MSK_RES_TRM_MAX_NUM_SETBACKS
          rcode == 0)
    if ~isempty(itr) && ...
       isfield(itr, 'xx') && ...
       isempty(find(~isfinite(itr.xx)))
      xsol = itr.xx;
      flag = 0;
      if nargout >= 3
        info.sol = itr;
        info.fval = itr.pobjval;

        inactive_Aeq = [];
        inactive_A = find(itr.skc ~= 4);
        %inactive_A = inactive_A(find(itr.suc(inactive_A) < 1e-7));
        %inactive_A = find(itr.suc < 1e-7);
        if prb.nqc > 0
          inactive_A(find(inactive_A <= prb.nqc)) = [];
          inactive_A = inactive_A - prb.nqc;
        end
        if prb.neq > 0
          i = find(inactive_A <= prb.neq);
          inactive_Aeq = inactive_A(i);
          inactive_A(i) = [];
          inactive_A = inactive_A - prb.neq;
        end
        info.inactive_Aeq = inactive_Aeq;
        info.inactive_A = inactive_A;
      end
    elseif ~isempty(bas) && ...
           isfield(bas, 'xx') && ...
           isfinite(bas.pobjval)
      xsol = bas.xx;
      flag = 0;
      if nargout >= 3
        info.fval = bas.pobjval;
        info.sol = bas;
      end
    else
      res
      error('No solution field!?');
    end
  elseif rcode == 10007 % user interrupt
    error('User interrupt.');
  else
    %% http://docs.mosek.com/7.0/capi/Response_codes.html
    warning(['mosek failed: ' res.rcodestr ...
             ' (' num2str(rcode) '), flag: ' num2str(flag)]);
    if 1295 == rcode
      error('Non-positive definite Hessian!');
    elseif 1200 == rcode
      nc = size(prb.c)
      na = size(prb.a)
      nblc = size(prb.blc)
      nbuc = size(prb.buc)
      if isfield(prb, 'blx'), nblx = size(prb.blx), end
      if isfield(prb, 'bux'), nbux = size(prb.bux), end
      %if isfield(prb, 'sol'), nxx = size(prb.sol.itr.xx), end
      %if isfield(res, 'sol')
        %res_sol_itr = res.sol.itr
      %end
    end
    flag = -9;
  end

  if flag == -1
    xsol = [];
  end
end
