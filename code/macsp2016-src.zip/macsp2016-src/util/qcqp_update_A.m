
function prb = qcqp_update_A(prb, rows, cols, vals)
%%% prb = qcqp_updateA(prb, rows, cols, vals)
%%%
%%% Update A matrix related to indices rows and cols.
%%%
  if prb.nqc > 0
    rows = rows + prb.nqc;
  end
  if prb.neq > 0
    rows = rows + prb.neq;
  end
  prb.a(rows, cols) = vals;
end

