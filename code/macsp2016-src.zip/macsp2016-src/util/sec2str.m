
function str = sec2str(seconds)
  h = floor(seconds/3600);
  t = seconds - h*3600;
  m = floor(t/60);
  s = ceil(t - m*60);
  if h > 0
    str = sprintf('%dh%dm%ds', h, m, s);
  elseif m > 0
    str = sprintf('%dm%ds', m, s);
  else
    str = sprintf('%ds', s);
  end
end

