
function prb = qcqp_update_lb(prb, idx, value, varargin)
  if nargin > 3 && varargin{1}
    prb.blx(idx) = max(prb.blx(idx), value);
  else
    prb.blx(idx) = value;
  end
end
