
function string = realformat(real, width)
    if ~isfinite(real)
        string = num2str(real);
        return;
    end

    intwidth = log10(abs(real));
    if mod(intwidth,1) == 0
        intwidth = intwidth + 1;
    else
        intwidth = ceil(intwidth);
    end
    intwidth = max(1, intwidth);
    if real < 0, intwidth = intwidth + 1; end
    fracwidth = max(0, width - intwidth - 1);

    if abs(real) >= 1
        string = sprintf(['%' num2str(intwidth) ...
                          '.' num2str(fracwidth) 'f'], real);
    else
        string = sprintf(['%' num2str(intwidth) ...
                          '.' num2str(fracwidth) 'f'], real);
    end
end

