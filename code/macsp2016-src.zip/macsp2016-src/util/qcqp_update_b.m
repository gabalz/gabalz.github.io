
function prb = qcqp_update_b(prb, idx, value)
  if prb.nqc > 0
    idx = idx + prb.nqc;
  end
  if prb.neq > 0
    idx = idx + prb.neq;
  end
  prb.buc(idx) = value;
end
