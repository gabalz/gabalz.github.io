
function prb = qcqp_removeAeq(prb, idx)
%%% prb = qcqp_removeAeq(prb, idx)
%%%
%%% Remove Aeq constraints related to indices in idx.
%%%
  if prb.nqc > 0
    idx = idx + prb.nqc;
  end
  prb.a(idx,:) = [];
  prb.blc(idx) = [];
  prb.buc(idx) = [];
end
