
function alg = cap(varargin)
% alg = cap(fast,logMult,knotNum)
%
% Convex adaptive partitioning (CAP) algorithm.
%
%    L. A. Hannah and D. B. Dunson, Multivariate Convex Regression with Adaptive Partitioning,
%    Journal of Machine Learning Research, Vol. 14, pp. 3207-3240, 2013
%
%    Source: http://www.columbia.edu/~lah2178/Research.html
%
  alg = algorithm();
  alg.data.name = 'CAP';

  alg.data.fast = 0;
  if nargin >= 1
    fast = varargin{1};
    if ischar(fast)
      if strcmpi(fast,'fast')
        fast = 1;
      else
        fast = 0;
      end
    end
    alg.data.fast = fast;
    if fast, alg.data.name = 'FastCAP'; end
  end

  alg.data.knotNum = 10;
  if nargin >= 2
    alg.data.knotNum = varargin{2};
  end

  alg.data.logMult = 3;
  if nargin >= 3
    alg.data.logMult = varargin{3};
  end

  alg.data.salt = 0;
  if nargin >= 4
    alg.data.salt = varargin{4};
  end

  alg.data.scaling = false;
  if nargin >= 5
    alg.data.scaling = varargin{5};
  end

  alg.train = @(X, y, varargin) cap_train(alg, X, y);
  alg.predict = @(alg, model, X) ma_lse_predict(model, X);
end

function [model,stat] = cap_train(alg,X,y)
  logMult = alg.data.logMult;
  knotNum = alg.data.knotNum;
  salt = alg.data.salt;
  scaling = alg.data.scaling;

  if size(X,1) ~= size(y,1)
    error('y has incorrect number of rows');
  end

  if scaling
    tol = 1e-6;
    meanX = mean(X,1);
    X = bsxfun(@minus, X, meanX);
    [U,s,V] = svd(X, 'econ');
    s = diag(s);
    Xscale = max(1, s(1));
    s = s / Xscale;
    ic = find(s < tol);
    if ~isempty(ic)
      U(:,ic) = [];
      s(ic) = [];
      V(:,ic) = [];
    end
    meany = mean(y);
    y = y - meany;
    yscale = max(1, max(abs(y)));
    y = y / yscale;
    X = bsxfun(@times, U, s');
    clear U s ic;
  end

  if ~isempty(salt) && salt > 0
    X = X + randn(size(X))*salt;
    %%X = X + (2*rand(size(X))-1)*salt;
  end
  
  if alg.data.fast
    [alpha, beta] = CAPfast(X, y, 0, logMult, knotNum);
  else
    [alpha, beta, ~, niter] = CAP(X, y, 0, logMult, knotNum);
  end
  model = struct();
  model.G = beta';
  model.v = alpha';

  if scaling
    model.G = model.G*V' * (yscale/Xscale);
    model.v = meany + model.v*yscale - model.G*meanX';
  end

  stat = struct();
  stat.niter = niter;
  stat.msize = numel(model.v);
end

