
function w = CAPregress(y, X1)
  w = (X1'*X1 + 1e-8*eye(size(X1,2))) \ (X1'*y);
end

