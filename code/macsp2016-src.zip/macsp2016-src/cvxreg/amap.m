
function alg = amap(varargin)
%%% alg = amap()
%%%
  alg = algorithm();
  alg.data.name = 'AMAP';

  alg.data.nfolds = 10;
  if nargin >= 1
    arg = varargin{1};
    if ~isempty(arg), alg.data.nfolds = arg; end
  end

  alg.data.mincellsize = 'max(d+1, ceil(log2(n)))';
  if nargin >= 2
    arg = varargin{2};
    if ~isempty(arg), alg.data.mincellsize = arg; end
  end

  alg.data.nfinalsteps = 5;
  if nargin >= 3
    arg = varargin{3};
    if ~isempty(arg), alg.data.nfinalsteps = arg; end
  end

  alg.heartbeat = true;
  if nargin >= 4
    arg = varargin{4};
    if ~isempty(arg), alg.heartbeat = arg; end
  end

  alg.shuffle = true;
  if nargin >= 5
    arg = varargin{5};
    if ~isempty(arg), alg.shuffle = arg; end
  end

  alg.train = @(X, y, varargin) amap_train(alg, X, y);
  alg.predict = @(alg, model, X) ma_lse_predict(model, X);
  alg.zeromodel = @(d) struct('v', 0, 'G', zeros(1,d));
end

function [model, stat] = amap_train(alg, X, y)
  tol = 1e-6;
  heartbeat = alg.heartbeat;
  stat = struct();

  [n, d] = size(X);
  if n <= d, warning('Too few data points!'); end

  nfolds = alg.data.nfolds;
  if ischar(nfolds), nfolds = eval(nfolds); end
  mincellsize = alg.data.mincellsize;
  if ischar(mincellsize), mincellsize = eval(mincellsize); end
  nfinalsteps = alg.data.nfinalsteps;
  if ischar(nfinalsteps), nfinalsteps = eval(nfinalsteps); end

  %% shuffle the data

  if alg.shuffle
    perm = randperm(n);
    X = X(perm,:);
    y = y(perm);
    clear perm;
  end

  %% scaling the data

  meanX = mean(X,1);
  X = bsxfun(@minus, X, meanX);
  [U,s,V] = svd(X, 'econ');
  s = diag(s);
  Xscale = max(1, s(1));
  s = s / Xscale;
  ic = find(s < tol);
  if ~isempty(ic)
    d = d - numel(ic);
    U(:,ic) = [];
    s(ic) = [];
    V(:,ic) = [];
  end
  meany = mean(y);
  y = y - meany;
  yscale = max(1, max(abs(y)));
  y = y / yscale;
  X = bsxfun(@times, U, s');
  clear U s ic;

  %% constants

  X = [ones(n,1) X];
  betaI = tol*eye(d+1);
  betaI(1,1) = 0;
  tlimit = ceil(n^(d/(d+4)));

  %% data partitioning

  chunk_tr = {};
  chunk_ts = {};
  chunk_off = 0;
  chunk_num = max(1, round(n/nfolds));
  for f = 1:nfolds
    chunkf = chunk_off + [1:chunk_num];
    if chunkf(end) > n
      chunkf(find(chunkf > n)) = [];
    end
    chunk_ts{f} = chunkf;
    chunkf = setdiff([1:n], chunkf);
    chunk_tr{f} = chunkf;
    chunk_off = chunk_off + chunk_num;
  end
  clear chunk_off chunk_num chunkf;

  %% initialization

  P = {};
  W = {};
  XW = {};
  err = zeros(nfolds,1);
  for f = 1:nfolds
    chunkf = chunk_tr{f};
    P{f} = {[1:numel(chunkf)]'};
    W{f} = lsfit(X(chunkf,:), y(chunkf), betaI);
    XW{f} = X(chunkf,:)*W{f};
    err(f) = mean((XW{f}-y(chunkf)).^2);
  end

  tserrs = [];
  for f = 1:nfolds
    chunkf = chunk_ts{f};
    tserrs = [tserrs, mean((X(chunkf,:)*W{f}-y(chunkf)).^2)];
  end
  best_cverr = mean(tserrs);
  best_W = W;

  %% cross-validation training

  niter = 0;
  maxiter = min(nfinalsteps, tlimit);
  tserrs = zeros(nfolds,1);
  if heartbeat, fprintf(1, '     '); end
  while niter < maxiter
    niter = niter + 1;
    if heartbeat, fprintf(1, '.'); end

    for f = 1:nfolds
      if numel(P{f}) < niter, continue; end

      chunk_trf = chunk_tr{f};
      [P{f}, W{f}, XW{f}, err(f)] = ...
        compute_amap_chunk(X(chunk_trf,:), y(chunk_trf), ...
                           P{f}, W{f}, XW{f}, err(f), ...
                           mincellsize, betaI);
      chunk_tsf = chunk_ts{f};
      tserrs(f) = mean((max(X(chunk_tsf,:)*W{f},[],2)-y(chunk_tsf)).^2);
    end

    cverr = mean(tserrs);
    if cverr < best_cverr - tol
      best_cverr = cverr;
      best_W = W;
      maxiter = min(niter + nfinalsteps, tlimit);
    end
  end
  if heartbeat, fprintf(1, '\n'); end

  %% choosing the final model
  
  W = best_W;
  best_err = inf;
  best_W = [];
  for f = 1:nfolds
    err = mean((max(X*W{f},[],2) - y).^2);
    if err < best_err
      best_err = err;
      best_W = W{f};
    end
  end

  model = struct();
  model.v = best_W(1,:)';
  model.G = best_W(2:end,:)';

  %% scaling the model

  model.G = model.G*V' * (yscale/Xscale);
  model.v = meany + model.v*yscale - model.G*meanX';

  %% final statistics

  stat.max_slope = sqrt(max(sum(model.G.^2,2)));
  stat.model_size = numel(model.v);
end

function [P, W, XW, err] = compute_amap_chunk(X, y, P, W, XW, err, ...
                                              mincellsize, betaI)
  K = numel(P);
  d = size(X,2)-1;

  %% find the best candidate split

  besterr = err;
  bestk = [];

  for k = 1:K
    cell = P{k};
    ncell = numel(cell);
    if ncell < 2*mincellsize, continue; end

    Xcell = X(cell,:);
    ycell = y(cell);

    XWk = XW(:,k);
    XW(:,k) = -inf;
    maxXWk = max(XW, [], 2);
    XW(:,k) = XWk;

    for dir = 2:1+d
      split = median(Xcell(:,dir));
      i1 = find(Xcell(:,dir) < split);
      i2 = find(Xcell(:,dir) > split);
      ni1 = numel(i1);
      ni2 = numel(i2);
      if ni1+ni2 < ncell
        i3 = find(Xcell(:,dir) == split);
        if ni1 < mincellsize
          i1 = [i1; i3(1:ni1-mincellsize)];
          i3(1:ni1-mincellsize) = [];
        end
        if ni2 < mincellsize
          i2 = [i2; i3(1:ni2-mincellsize)];
          i3(1:ni2-mincellsize) = [];
        end
        ni3 = numel(i3);
        if ni3 > 0
          i1 = [i1; i3(1:floor(ni3/2))];
          i2 = [i2; i3(ceil(ni3/2):end)];
        end
      end

      w1 = lsfit(Xcell(i1,:), ycell(i1), betaI);
      w2 = lsfit(Xcell(i2,:), ycell(i2), betaI);

      candy = max(max(X*w1, X*w2), maxXWk);
      canderr = mean((candy-y).^2);

      if canderr < besterr
        bestk = k;
        besti1 = i1;
        besti2 = i2;
        bestw1 = w1;
        bestw2 = w2;
        besterr = canderr;
      end
    end
  end
  if isempty(bestk), return; end

  %% fit the new partition

  K = K+1;
  cell = P{bestk};
  P{bestk} = cell(besti1);
  P{K} = cell(besti2);
  W(:,bestk) = bestw1;
  W(:,K) = bestw2;
  XW = X*W;
  err = besterr;

  while true
    %% compute the induced partition
    [~, active] = max(XW, [], 2);
    candP = arrayfun(@(k) find(active==k), 1:K, 'uni', false);
    
    %% stop when minimum cell size requirement is violated
    if ~isempty(find(cellfun(@numel, candP) < mincellsize)), break; end

    %% fit the induced partition
    candW = zeros(d+1,K);
    for k = 1:K
      cell = candP{k};
      candW(:,k) = lsfit(X(cell,:), y(cell), betaI);
    end
    candXW = X*candW;
    canderr = mean((max(candXW,[],2) - y).^2);

    %% update partition or stop
    if canderr < err
      P = candP;
      W = candW;
      XW = candXW;
      err = canderr;
    else
      break;
    end
  end
end

function w = lsfit(X1, y, betaI)
  w = (X1'*X1 + betaI) \ (X1'*y);
end

