
function alg = algorithm()
    alg = struct();

    alg.data = struct();
    alg.data.name = 'unknown algorithm';

    alg.train = @(X,y) error('missing algorithm train');
    alg.predict = @(alg,model,X) error('missing algorithm predict');
end
