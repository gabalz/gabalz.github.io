
clear all;
setup;

global use_single_thread_optim;
use_single_thread_optim = true;

%------------------------------------------------------------------------------

spec = struct();
spec.istest = true;
runfile = 'run_plan_esp.m';
outdir = ['..' filesep 'result' filesep];

%% problem parameters

spp = @() ESP(2); % two days horizon
%spp = @() ESP(2, 1, 24); % one day horizon
%spp = @() ESP(2, 1, 12); % half day horizon

%% experiment parameters

spec.seed = 45510113; % experiment seed (set empty for auto)
%spec.sync_sim_seed = true; % use the same seed for all simulations
spec.nrep = 100; % number of experiment repetitions
spec.nsim = 1000; % number of simulations per experiment
%spec.repchunk = 1:10;

%% algorithm parameters

ntraj = 2500; % number of trajectories
neval = 100; % number of evaluations per trajectory
nchains = '100';

%------------------------------------------------------------------------------

dms = {}; % decision makers

dms{end+1} = dm_esp_nos();
dms{end+1} = dm_esp_ons();

dms{end+1} = dm_ma(amap([],[],[],false), ntraj, neval, nchains);
dms{end+1} = dm_ma(cap('nofast',10,3,1e-4,true), ntraj, neval, nchains);

spec.ntraj = ntraj;
spec.neval = neval;
spec.nchains = nchains;

%-----------------------------------------------------------------------------

tstart = tic;
[spp, result, exmtdir, csc_mean, csc_std, dmi_names] = ...
  exmtSPP(spp, dms, spec, runfile, outdir);
exmt_time = toc(tstart)

