
function spp = SPP(pname, t1, T, x0, z0, cost, Xsampler, Zsampler, ...
                   optdim, fixvars, dynamics, fixXSt)
  spp = struct();
  spp.pname = pname;

  spp.t1 = t1;
  spp.T = T;
  spp.x0 = x0;
  spp.z0 = z0;

  spp.cost = cost;
  spp.Xsampler = Xsampler;
  spp.Zsampler = Zsampler;
  spp.optdim = optdim;
  spp.fixvars = fixvars;
  spp.dynamics = dynamics;

  spp.checkXt = @(Xt, t, X, Z, tol) spp_checkXt(spp, Xt, t, X, Z, tol);
  spp.fixXSt = fixXSt;
end

%% TODO
function X = spp_Xsampler(t, n, spp, Xt, Zt, bndrt, nchains)
  [dim, A, b, Aeq, beq, lb, ub, fXZ, ~, ...
   XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
   XZidxlb, XZdimlb, XZidxub, XZdimub] = spp.dynamics(t);

   %% ...
   X = [];
end

function [Xt, viol] = spp_checkXt(spp, Xt, t, X, Z, tol)
  viol = 0;

  n = size(Xt,1);
  [~, A, b, Aeq, beq, lb, ub, fXZ, fPP, ...
   XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
   XZidxlb, XZdimlb, XZidxub, XZdimub] = spp.dynamics(t);

  XZ = fXZ(t, X, Z);

  if ~isempty(lb)
    L = repmat(lb', n, 1);
    if ~isempty(XZidxlb)
      L(:,XZidxlb) = XZ(:,XZdimlb);
    end
    assert (isempty(find(isnan(L),1)));

    LXt = L - Xt;
    viol = max(viol, max(max(max(0, LXt))));

    k = find(LXt > tol,1);
    if ~isempty(k)
      [i,j] = ind2sub(size(Xt), k);
      warning(['! Xt(' num2str(i) ',' num2str(j) ')=' num2str(Xt(i,j)) ...
               ' < L(' num2str(i), ',' num2str(j) ')=' num2str(L(i,j)) ...
               ', diff=' num2str(Xt(i,j)-L(i,j))]);
    end
    Xt = max(Xt, L);
  end

  if ~isempty(ub)
    U = repmat(ub', n, 1);
    if ~isempty(XZidxub)
      U(:,XZidxub) = XZ(:,XZdimub);
    end
    assert (isempty(find(isnan(U),1)));

    XtU = Xt - U;
    viol = max(viol, max(max(max(0, XtU))));

    k = find(XtU > tol, 1);
    if ~isempty(k)
      [i,j] = ind2sub(size(Xt), k);
      warning(['! Xt(' num2str(i) ',' num2str(j) ')=' num2str(Xt(i,j)) ...
               ' > U(' num2str(i) ',' num2str(j) ')=' num2str(U(i,j)) ...
               ', diff=' num2str(Xt(i,j)-U(i,j))]);
    end
    Xt = min(Xt, U);
  end

  if ~isempty(A)
    B = repmat(b', n, 1);
    if ~isempty(XZidxA)
      B(:,XZidxA) = XZ(:,XZdimA);
    end
    assert (isempty(find(isnan(B),1)));

    AXtb = Xt*A' - B;
    viol = max(viol, max(max(max(0, AXtb))));

    k = find(AXtb > tol, 1);
    if ~isempty(k)
      [i,j] = ind2sub(size(AXtb), k);
      warning(['! (A*Xt-B)(' num2str(i) ',' num2str(j) ')=' num2str(AXtb(i,j)) ...
               ', A(' num2str(j) ',:)=' mat2str(full(A(j,:))) ...
               ', b=' num2str(B(i,j))]);
    end
  end

  if ~isempty(Aeq)
    Beq = repmat(beq', n, 1);
    if ~isempty(XZidxAeq)
      Beq(:,XZidxAeq) = XZ(:,XZdimAeq);
    end
    assert (isempty(find(isnan(Beq),1)));

    AeqXtbeq = Xt*Aeq' - Beq;
    viol = max(viol, max(max(max(0, AeqXtbeq))));

    k = find(abs(AeqXtbeq) > tol, 1);
    if ~isempty(k)
      [i,j] = ind2sub(size(AeqXtbeq), k);
      warning(['! (Aeq*Xt-Beq)(' num2str(i) ',' num2str(j) ')=' num2str(AeqXtbeq(i,j)) ...
               ', Aeq(' num2str(j) ',:)=' mat2str(full(Aeq(j,:))) ...
               ', Xt(' num2str(i) ',:)=' mat2str(full(Xt(i,:))) ...
               ', beq=' num2str(Beq(i,j))]);
    end
  end

  Xt = fPP(t, Xt, X, Z);
end

