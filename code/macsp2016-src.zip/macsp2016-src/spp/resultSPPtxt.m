
function resultSPPtxt(outfname, spec, spp_pname, spp_t1, spp_T, dmi_names, result)
  global system_info;

  repchunk = find(~cellfun(@isempty, result(:,1)))';

  fid = fopen(outfname, 'wt');
  try
    fprintf(fid, '\n');
    fprintf(fid, [system_info ' (' timestamp() ')\n']);

    fprintf(fid, '\n');
    fprintf(fid, 'SPP: %s(%d:%d)\n', spp_pname, spp_t1, spp_T);

    fprintf(fid, '\n');
    reschunk = result(repchunk,:);
    dr = cellfun(@(e) e.csc_mean(end), reschunk);
    dtst = cellfun(@(e) e.info.tsetup, reschunk);
    dtsm = cellfun(@(e) e.info.tsim, reschunk);
    clear reschunk;
    for alg = 1:size(result,2)
      r = dr(:,alg);
      tst = dtst(:,alg);
      tsm = dtsm(:,alg);
      fprintf(fid, '  %10s | %7s/%7s | %5s/%5s | %5s/%5s\n', ...
              dmi_names{alg}, ...
              realformat(-mean(r),7), realformat(std(r),7), ...
              realformat(mean(tst),5), realformat(std(tst),5), ...
              realformat(mean(tsm),5), realformat(std(tsm),5));
    end

    fprintf(fid, '\n');
    fprintf(fid, 'Spec:\n\n');
    fprint_struct_fields(fid, spec, '  ');

    fprintf(fid, '\n');
    for rep = repchunk
      fprintf(fid, 'rep: %d\n', rep);
      for alg = 1:size(result,2)
        r = result{rep,alg};
        fprintf(fid, '  %10s | %7s/%7s | %5s | %5s\n', ...
                     dmi_names{alg}, ...
                     realformat(-r.csc_mean(end),7), ...
                     realformat(r.csc_std(end),7), ...
                     realformat(r.info.tsetup,5), ...
                     realformat(r.info.tsim,5));
      end
    end

    fprintf(fid, '\n');
    fclose(fid);
  catch exception
    fclose(fid);
    rethrow(exception);
  end
end

