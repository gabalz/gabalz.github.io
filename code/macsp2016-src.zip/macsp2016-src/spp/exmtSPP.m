
function [spp, result, exmtdir, csc_mean, csc_std, dmi_names] = ...
         exmtSPP(spp, dms, spec, script, outdir)
  seed_limit = 1e8;
  csc_mean = [];
  csc_std = [];

  ndms = numel(dms);
  spp = spp();

  if ~isfield(spec,'seed') || isempty(spec.seed)
    clk = clock();
    spec.seed = round(clk(6)*1e6);
    clear clk;
  end

  exmtts = timestamp('compact');
  fprintf(1, [spp.pname ', ' exmtts ', seed:' num2str(spec.seed) '\n']);

  exmtdir = [hostname() '-' lower(spp.pname)];
  if isfield(spec, 'neval')
    exmtdir = [exmtdir '-m' num2str(spec.neval)];
  end
  if isfield(spec, 'ntraj')
    exmtdir = [exmtdir '-t' num2str(spec.ntraj)];
  end
  if isfield(spec, 'istest') && spec.istest
    exmtdir = ['test-' exmtdir];
  end
  if exist([outdir exmtdir])
    exmtdir = [exmtdir '-' exmtts];
  end
  exmtdir = [exmtdir filesep];
  if exist([outdir exmtdir])
    error(['Experiment directory already exists: ' exmtdir]);
  else
    mkdir(outdir, exmtdir);
    exmtdir = [outdir exmtdir];
  end
  [status,msg] = copyfile(script, [exmtdir script '-' exmtts]);
  spp_pname = spp.pname;
  spp_t1 = spp.t1;
  spp_T = spp.T;
  exmtfile = [exmtdir 'result.mat'];
  save(exmtfile, '-v7', 'spp_pname', 'spp_t1', 'spp_T', 'ndms', 'spec');
  clear status msg spp_pname;

  rng_set_seed(spec.seed);
  if isfield(spec, 'sync_sim_seed')
    sim_seed = randi(seed_limit, 1, 1)*ones(spec.nrep,1);
  else
    sim_seed = randi(seed_limit, spec.nrep, 1);
  end
  setup_seed = randi(seed_limit, spec.nrep, 1);

  repchunk = 1:spec.nrep;
  if isfield(spec,'repchunk') && ~isempty(spec.repchunk)
    repchunk = spec.repchunk;
  end

  result = {};
  dmi_names = {};
  for rep = repchunk
    fprintf(1, '  rep: %d / %d\n', rep, repchunk(end));

    for dmi = 1:ndms
      dm = dms{dmi};
      if numel(dmi_names) < ndms
        dmi_names{end+1} = dm.name;
      end

      ts = tic;
      fprintf(1, '  %10s|', dm.name);
      [X, Z, c, info] = simulateSPP(spp, spec.nsim, dm, ...
                                    setup_seed(rep), ...
                                    sim_seed(rep));
      r = struct();
      r.sim_time = toc(ts);
      %r.X = X; r.Z = Z; r.c = c;
      r.csc = cumsum(c,2);
      r.csc_mean = mean(r.csc(:,end));
      r.csc_std = std(r.csc(:,end));
      r.info = info;
      result{rep,dmi} = r;

      fprintf(1, ['|' num2str(-r.csc_mean(end)) ...
                  '|' sec2str(r.sim_time) '\n']);
      save(exmtfile, '-append', 'result');
    end
    if rep == 1
      save(exmtfile, '-append', 'dmi_names');
    end
  end

  if numel(repchunk) == spec.nrep
    csc_mean = {};
    csc_std = {};
    for dmi = 1:ndms
      csc = cell2mat(cellfun(@(c) c.csc_mean, result(:,dmi), 'uni', false));
      csc_mean{dmi} = mean(csc, 1);
      csc_std{dmi} = std(csc, 0, 1);
    end
    save(exmtfile, '-append', 'csc_mean', 'csc_std');
  end

  exmtfiletxt = [exmtdir 'result.txt'];
  resultSPPtxt(exmtfiletxt, spec, spp.pname, spp.t1, spp.T, dmi_names, result);
end
