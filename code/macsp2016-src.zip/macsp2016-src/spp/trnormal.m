
function distr = trnormal(t, loc, scl, minv, maxv)
  i = mod(t-1,24)+1;
  s = scl(i);
  if s > 0
    distr = distr_trnormal(1, loc(i), scl(i), maxv, minv);
  elseif s == 0
    distr = distr_constant(loc(i));
  else
    error(['Negative scl: ' num2str(s) '!']);
  end
end

