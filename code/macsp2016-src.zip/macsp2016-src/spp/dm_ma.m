
function dm = dm_ma(alg, nsim, neval, nchains)
%%% Decision maker based on max-affine estimation.
%%%
  dm = struct();
  dm.name = ['dm-' alg.data.name];
  dm.nsim = nsim;
  dm.neval = neval;

  dm.nchains = 1;
  if nargin > 3
    dm.nchains = nchains;
  end

  qcqp_params = struct();
  qcqp_params.p1 = struct();
  qcqp_params.p2 = struct();

  qcqp_params.p2.MSK_IPAR_OPTIMIZER = 1; % MSK_OPTIMIZER_PRIMAL_INTPNT
  qcqp_params.p2.MSK_IPAR_INTPNT_MAX_ITERATIONS = 10000;
  qcqp_params.p2.MSK_IPAR_INTPNT_BASIS = 0; % MSK_OFF
  %qcqp_params.p2.MSK_DPAR_INTPNT_TOL_INFEAS = 5e-8;

  qcqp_params.p1.MSK_IPAR_OPTIMIZER = 3; % MSK_OPTIMIZER_PRIMAL_SIMPLEX
  qcqp_params.p1.MSK_IPAR_SIM_SOLVE_FORM = 1; % MSK_SOLVE_PRIMAL
  qcqp_params.p1.MSK_IPAR_SIM_PRIMAL_SELECTION = 1; % MSK_SIM_SELECTION_FULL
  qcqp_params.p1.MSK_DPAR_BASIS_TOL_X = 1e-4;
  qcqp_params.p1.MSK_DPAR_BASIS_TOL_S = 1e-6;
  qcqp_params.p1.MSK_DPAR_BASIS_REL_TOL_S = 1e-6;

  dm.setup = @(spp) setup(spp, alg, dm, qcqp_params);
  dm.solve = @(data, t, X, Z) solve(data, t, X, Z, qcqp_params);
end

function [data, info] = setup(spp, alg, dm, qcqp_params)
%%%
  info = struct();
  nsim = dm.nsim;
  neval = dm.neval;
  nchains = dm.nchains;

  ts = tic;
  X = {};
  Z = {};
  Xp = spp.x0';
  Zp = spp.z0';
  for t = spp.t1:spp.T
    ti = t - spp.t1 + 1;
    X{ti} = spp.Xsampler(t, nsim, Xp, Zp, 0, nchains);
    Z{ti} = spp.Zsampler(t, nsim);
    Xp = X{ti};
    Zp = Z{ti};
  end
  clear Xp Zp Xti;
  info.tsampling = toc(ts);

  J = {};
  J{spp.T+1-spp.t1+1} = [];

  te = zeros(1,spp.T-spp.t1+1);
  tt = zeros(1,spp.T-spp.t1+1);

  t = spp.T;
  tistep = spp.T+1;
  while t >= spp.t1
    ti = t - spp.t1 + 1;
    if ti <= tistep
      fprintf(1, '.');
      tistep = tistep - (spp.T-spp.t1)/10;
    end

    ts = tic;
    prb0 = [];
    yti = zeros(nsim,1);
    for ei = 1:neval
      Xti = X{ti};
      if ei == 1
        Zti = Z{ti};
      else
        Zti = spp.Zsampler(t, nsim);
      end
      yti = yti + spp.cost(t, Xti, Zti)/neval;
      J1 = J{ti+1};
      if ~isempty(J1)
        [ynew, ~, prb0] = estimate(spp, t+1, J1, Xti, Zti, qcqp_params, [], prb0);
        yti = yti + ynew/neval;
      end
    end
    te(ti) = te(ti) + toc(ts);

    ts = tic;
    J{ti} = alg.train(Xti, yti);
    tt(ti) = tt(ti) + toc(ts);

    t = t-1;
  end
  data.J = J;
  data.spp = spp;

  info.te = te;
  info.tt = tt;
end

function [XSt, vt] = solve(data, t, X, Z, qcqp_params)
  spp = data.spp;
  ti = t-data.spp.t1+1;
  [vt, XSt] = estimate(spp, t, data.J{ti}, X, Z, qcqp_params);
  if ~isempty(spp.fixXSt)
    tol = 2^-25;
    XSt = spp.fixXSt(XSt, X, Z, tol);
  end
end

function [y, X, prb0] = estimate(spp, t, J, Xp, Zp, qcqp_params, chunksize, prb0)
  n = size(Xp, 1);
  assert (size(Zp,1) == n);
  d = spp.optdim(t);
  fx = spp.fixvars(t);

  y = zeros(n, 1);
  X = zeros(n, d);

  if nargin < 7 || isempty(chunksize)
    chunksize = ceil(min(min(1000/d, n), 1000/numel(J.v)));
  end
  leftover = mod(n, chunksize);
  nchunks = floor(n / chunksize);

  td = tic;

  if nargin < 8 || isempty(prb0)
    prb0 = struct();
    prb0.x0 = [];
    prb0.x0_lo = [];
  end

  [prb, prb_updater] = get_empty_prb(spp, t, J, chunksize, fx);
  if 0 < leftover
    [prb_lo, prb_updater_lo] = get_empty_prb(spp, t, J, leftover, fx);
  end

  i = 1:chunksize;
  for chunk = 1:nchunks
    if ~isempty(prb0.x0)
      prb = qcqp_update_x0(prb, [], prb0.x0.sol, qcqp_params.p1);
    end
    prb = prb_updater(prb, Xp(i,:), Zp(i,:));
    [xsol, flag, info] = lp_solve(prb, qcqp_params.p1);
    if flag < 0
      [xsol, flag, info] = lp_solve(prb, qcqp_params.p2);
      if flag < 0
        %s = prb.blx(2:10);
        %x = [0; s; zeros(7,1)];
        xsol = info.sol.xx;
        viol = abs(min(min(min(xsol-prb.blx), min(prb.bux-xsol)), ...
                       min(prb.buc-prb.a*xsol)));
        if viol > 1e-6
          viol
          save('debug-dm-viol.mat', '-v7', 'prb', 'xsol', 'viol', 'info');
          error(['Could not solve prb, flag = ' num2str(flag) '!']);
        end
      end
    end
    prb0.x0 = info;
    y(i) = xsol(1:chunksize);
    X(i,:) = reshape(xsol(chunksize+1:end), d, chunksize)';
    i = i + chunksize;
  end

  if 0 < leftover
    i = n-leftover+1:n;
    prb_lo = prb_updater_lo(prb_lo, Xp(i,:), Zp(i,:));
    if ~isempty(prb0.x0_lo)
      prb_lo = qcqp_update_x0(prb_lo, [], prb0.x0_lo.sol, qcqp_params.p1);
    end
    [xsol, flag, info] = lp_solve(prb_lo, qcqp_params.p1);
    if flag < 0
      [xsol, flag, info] = lp_solve(prb_lo, qcqp_params.p2);
      if flag < 0
        xsol = info.sol.xx;
        viol = abs(min(min(min(xsol-prb_lo.blx), min(prb_lo.bux-xsol)), ...
                       min(prb_lo.buc-prb_lo.a*xsol)));
        if viol > 1e-6
          viol
          error(['Could not solve prb_lo, flag = ' num2str(flag) '!']);
        end
      end
    end
    prb0.x0_lo = info;
    y(i) = xsol(1:leftover);
    X(i,:) = reshape(xsol(leftover+1:end), d, leftover)';
  end
end

function [xsol, flag, info] = lp_solve(prb, params)
%%% TODO: This function is MOSEK specific!
%%%
  [xsol, flag, qinfo] = qcqp_solve(prb, params);

  info = struct();
  info.sol = qinfo.sol;

  %tol = 1e-5;
  %info.cidx = find(prb.a*xsol > prb.buc-tol);
end

function [prb, prb_updater] = get_empty_prb(spp, t, J, m, fx)
%%
%%        min         t1+...+tm, s.t. tj >= Gk'*xj+vk, xj in X(xj?,Zj?),
%% t1,...tm,x1,...,xm                 j=1,...,m, k=1,...,K
%%
%% xj? and Zj? are specified later using update_prb.
%% X(.,.) is represented by a polytope given by spp.dynamics(t).
%%
  [dim, A, b, Aeq, beq, lb, ub, fXZ, ~, ...
   XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
   XZidxlb, XZdimlb, XZidxub, XZdimub] = spp.dynamics(t);

  f = [ones(m,1); zeros(dim*m,1)];

  idxA = [];
  dimA = [];
  if ~isempty(A)
    nb = numel(b);
    A = [sparse(nb*m,m) kron(speye(m), sparse(A))];
    b = repmat(b, m, 1);
    if ~isempty(XZdimA)
      idxA = kron([0:m-1]', nb*ones(numel(XZdimA),1)) + repmat(XZidxA, m, 1);
      dimA = XZdimA;
    end
  end

  idxAeq = [];
  dimAeq = [];
  if ~isempty(Aeq)
    nbeq = numel(beq);
    Aeq = [sparse(nbeq*m,m) kron(speye(m), sparse(Aeq))];
    beq = repmat(beq, m, 1);
    if ~isempty(XZdimAeq)
      idxAeq = [kron([0:m-1]', nbeq*ones(numel(XZdimAeq),1)) + ...
                repmat(XZidxAeq, m, 1)];
      dimAeq = XZdimAeq;
    end
  end

  idxlb = [];
  dimlb = [];
  if ~isempty(lb)
    nlb = numel(lb);
    lb = [-inf(m,1); repmat(lb, m, 1)];
    if ~isempty(XZdimlb)
      idxlb = m + [kron([0:m-1]', nlb*ones(numel(XZdimlb),1)) + ...
                   repmat(XZidxlb, m, 1)];
      dimlb = XZdimlb;
    end
  end

  idxub = [];
  dimub = [];
  if ~isempty(ub)
    nub = numel(ub);
    ub = [+inf(m,1); repmat(ub, m, 1)];
    if ~isempty(XZdimub)
      idxub = m + [kron([0:m-1]', nub*ones(numel(XZdimub),1)) + ...
                   repmat(XZidxub, m, 1)];
      dimub = XZdimub;
    end
  end

  prb = qcqp_create([], f, A, b, Aeq, beq, lb, ub);

  Jv = J.v;
  JG = J.G;
  JGfx = [];
  fxidx = [];
  if ~isempty(fx)
    JGfx = JG(:,fx);
    JG = JG(:,setdiff([1:size(JG,2)]',fx));
    fxidx = numel(b) + [1:(m*numel(Jv))]';
  end

  prb = qcqp_update(prb, ...
                    [kron(speye(m), -ones(numel(Jv),1)) kron(speye(m), JG)], ...
                    repmat(-Jv, m, 1));

  prb_updater = @(prb, X, Z) update_prb(prb, t, X, Z, fXZ, fx, fxidx, JGfx, Jv, ...
                                        idxA, dimA, idxAeq, dimAeq, ...
                                        idxlb, dimlb, idxub, dimub);
end

function prb = update_prb(prb, t, X, Z, fXZ, fx, fxidx, JGfx, Jv, ...
                          XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
                          XZidxlb, XZdimlb, XZidxub, XZdimub)
  XZ = fXZ(t, X, Z);
  %ii = find(XZ < 0);
  %if ~isempty(ii)
  %  dt = XZ(ii)
  %  [i1,j1] = ind2sub(size(XZ), ii)
  %end

  if ~isempty(XZdimA)
    data = XZ(:,XZdimA)';
    prb = qcqp_update_b(prb, XZidxA, data(:));
  end
  if ~isempty(XZdimAeq)
    data = XZ(:,XZdimAeq)';
    prb = qcqp_update_beq(prb, XZidxAeq, data(:));
  end
  if ~isempty(XZdimlb)
    data = XZ(:,XZdimlb)';
    prb = qcqp_update_lb(prb, XZidxlb, data(:));
  end
  if ~isempty(XZdimub)
    data = XZ(:,XZdimub)';
    prb = qcqp_update_ub(prb, XZidxub, data(:));
  end
  if ~isempty(fx)
    data = bsxfun(@minus, -JGfx*(XZ(:,fx)'), Jv);
    prb = qcqp_update_b(prb, fxidx, data(:));
  end

  %% numerical stability hack
  %m = size(X,1);
  %minb = min(prb.buc)-1;
  %s = [minb*ones(m,1); zeros(size(prb.a,2)-m,1)];
  %buc = max(prb.a*s, prb.buc);
  %prb = qcqp_update_b(prb, 1:numel(prb.buc), buc);
end

