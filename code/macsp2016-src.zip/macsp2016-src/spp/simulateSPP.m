
function [X, Z, c, info] = simulateSPP(spp, n, dm, setup_seed, sim_seed, data)
%%%
  tol = 2^-16;
  seed_limit = 1e8;
  info = struct();

  if ~isempty(setup_seed)
    tstart = tic;
    rng_set_seed(setup_seed);
    [data, info.setup] = dm.setup(spp);
    info.tsetup = toc(tstart);
    fprintf(1, '|');
  elseif nargin < 6
    error('Missing setup seed and data!');
  end
  if isstruct(data) && isfield(data, 'spp')
    data.spp = spp;
  end

  rng_set_seed(sim_seed);
  sim_seed = randi(seed_limit);

  tstart = tic;
  X = {repmat(spp.x0', n, 1)};
  Z = {repmat(spp.z0', n, 1)};
  c = [];
  ti = 1;
  maxviol = 0;
  tistep = 0; 
  for t = spp.t1:spp.T
    if ti >= tistep
      fprintf(1, '.');
      tistep = tistep + (spp.T-spp.t1)/10;
    end

    Xt_1 = X{ti};
    Zt_1 = Z{ti};
    XSt = dm.solve(data, t, Xt_1, Zt_1);
    [Xt, viol] = spp.checkXt(XSt, t, Xt_1, Zt_1, tol);
    if viol > maxviol, maxviol = viol; end

    rng_set_seed(sim_seed);
    sim_seed = randi(seed_limit);

    ti = ti+1;
    X{ti} = Xt;
    Z{ti} = spp.Zsampler(t, n);
    c = [c, spp.cost(t, Xt, Z{ti})];
  end
  info.tsim = toc(tstart);

  if isfield(data, 'spp')
    data.spp = data.spp.pname;
  end
  info.data = data;
  info.maxviol = maxviol;
end

