
function spp = BB(varargin)
%%% Beer brewery problem.
%%%
  t1 = 1;
  if nargin >= 1
    arg = varargin{1};
    if ~isempty(arg), t1 = arg; end
  end

  T = 24;
  if nargin >= 2
    arg = varargin{2};
    if ~isempty(arg), T = arg; end
  end

  outfname = [];
  if nargin >= 3
    outfname = varargin{3};
  end

  F = sparse(9,9);
  F(sub2ind(size(F), [1 2 3 5 5 7 8 9 9], [1 2 3 4 5 6 7 8 9])) = 1;
  B = [-1 -0.5; -1 -0.9; -1 -0.8; 1 0; 0 0; 0 1; sparse(3,2)];
  R = [speye(3); sparse(6,3)];
  S = [sparse(4,2); 1 0; sparse(3,2); 0 1];
  k = [10; 10; 10; 10; inf; 10; inf(3,1)];
  h = [1 0.2 0.2 1 2 1 1 1 2]';
  c = [20 10 5 1 1]';
  r = [90 50]';
  FRBS = [F R B -S]';

  Dmin = 0.1;
  Dmax = 12;
  DlocL = [2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, ...
           6, 6, 9, 10, 10, 10, 8, 8, 6, 6, 5, 7]';
  DsclL = [1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, ...
           2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1]';
  distrDL = @(t) trnormal(t, DlocL, DsclL, Dmin, Dmax);
  DlocA = [3, 3, 3, 3, 2, 2, 3, 3, 3, 3, 3, 3, ...
           4, 4, 4, 4, 5, 5, 6, 6, 5, 5, 4, 5]';
  DsclA = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ...
           2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1]';
  distrDA = @(t) trnormal(t, DlocA, DsclA, Dmin, Dmax);
  Zsampler = @(t, n) bb_Zsampler(distrDL, distrDA, t, n);

  if outfname
    mDL = [];
    sDL = [];
    mDA = [];
    sDA = [];
    ti = [1:T-t1+1]';
    for h = ti'
      dL = distr_trnormal(1, DlocL(h), DsclL(h), Dmax, Dmin);
      mDL = [mDL; dL.mean];
      sDL = [sDL; dL.std];
      dA = distr_trnormal(1, DlocA(h), DsclA(h), Dmax, Dmin);
      mDA = [mDA; dA.mean];
      sDA = [sDA; dA.std];
    end
    csvwrite(outfname, [ti mDL sDL mDA sDA]);
    clear mDL sDL mDA sDA ti dL dA;
  end

  x0 = zeros(16,1);
  z0 = zeros(2,1);

  lb = zeros(7,1);
  ub = [inf(5,1); nan(2,1)];
  A = [sparse(9,3) -B S; R B sparse(9,2)];
  b = nan(18,1);
  hcr = [h; c; -r];

  fXZ = @(t,X,Z) bb_fXZ(X, FRBS, k, Z);
  Xsampler = @(t, n, Xt, Zt, varargin) ...
             bb_Xsampler(t, n, A, lb, ub, k, fXZ, Xt, Zt, varargin{:});

  cost = @(t, Xt, Zt) bb_cost(hcr, Xt);

  fPP = @(t,XS,X,Z) bb_fPP(XS, FRBS, X);
  dynamics = @(t) bb_dynamics(A, b, lb, ub, fXZ, fPP);
  optdim = @(t) numel(lb);
  fixvars = @(t) [1:9]';

  fixXSt = @(XS, X, Z, tol) fixXS(XS, Z, tol);

  spp = SPP('BB', t1, T, x0, z0, cost, Xsampler, Zsampler, ...
            optdim, fixvars, dynamics, fixXSt);

  p = struct();
  p.hcr = hcr;
  p.FRBS = FRBS;
  p.F = F;
  p.R = R;
  p.B = B;
  p.S = S;
  p.k = k;
  spp.private = p;
end

function X = bb_Xsampler(t, n, A, lb, ub, k, fXZ, Xt, Zt, bndrt, nchains)
  d = 16;

  if nargin < 10
    bndrt = 0;
  end
  if nargin < 11
    nchains = 1;
  elseif ischar(nchains)
    nchains = eval(nchains);
  end

  nburn = d*d;
  nsolve = 10;
  
  XZ = fXZ(t, Xt, Zt);
  lb = [min(XZ(:,1:9),[],1)'; lb];
  ub = [max(XZ(:,1:9),[],1)'; ub];
  ub(15:16) = max(XZ(:,end-1:end),[],1)';
  A = [[-speye(9); speye(9)] A];
  b = [zeros(9,1); k];

  X = zeros(n,d);
  nsamples = 0;
  nsamplesi = ceil(n/nchains);
  prb = qcqp_create([], zeros(d,1), A, b, [], [], lb, ub);
  for i = 1:nchains
    x0 = zeros(d,1);
    for j = 1:nsolve
      f = randn(d,1);
      f = f / norm(f);
      prb = qcqp_update_f(prb, 1:d, f);
      [x0j, flag] = qcqp_solve(prb);
      if flag ~= 0
        error(['Solving LP failed: ' num2str(flag) '!']);
      end
      x0 = x0 + x0j/nsolve;
    end
    Xi = polysample(A, b, lb, ub, x0, nsamplesi, nburn, bndrt);

    ns = min(nsamplesi, n-nsamples);
    X(nsamples+[1:ns],:) = Xi(1:ns,:);
    nsamples = nsamples + ns;
  end
  assert (nsamples == n);
end

function XZ = bb_fXZ(X, FRBS, k, Z)
  XFRBS = max(0,X*FRBS);
  XZ = [XFRBS max(0,bsxfun(@minus, k', XFRBS)) Z];
end

function XS = bb_fPP(XS, FRBS, X)
  XS = [X*FRBS XS];
end

function [dim, A, b, Aeq, beq, lb, ub, fXZ, fPP, ...
          XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
          XZidxlb, XZdimlb, XZidxub, XZdimub] = ...
         bb_dynamics(A, b, lb, ub, fXZ, fPP)
  dim = numel(lb);
  Aeq = [];
  beq = [];
  %- XZidxA = [];
  %- XZdimA = [];
  XZidxA = [1:18]';
  XZdimA = [1:18]';
  XZidxAeq = [];
  XZdimAeq = [];
  %- XZidxlb = [1:9]';
  %- XZdimlb = [1:9]';
  %- XZidxub = [XZidxlb; 15; 16];
  %- XZdimub = [XZdimlb; 10; 11];
  XZidxlb = [];
  XZdimlb = [];
  XZidxub = [6; 7];
  XZdimub = [19; 20];
end

function Z = bb_Zsampler(distrDL, distrDA, t, n)
  distrDLt = distrDL(t+1);
  distrDAt = distrDA(t+1);
  Z = [distrDLt.sampler(n), distrDAt.sampler(n)];
end

function c = bb_cost(hcr, Xt)
  c = Xt*hcr;
end

function X = fixXS(X, Z, tol)
  X = max(0, X);
end

