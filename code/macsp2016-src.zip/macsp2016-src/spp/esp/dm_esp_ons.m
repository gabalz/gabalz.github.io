
function dm = dm_esp_ons()
%%% Optimal decision maker for the energy problem without storage.
%%%
  dm = struct();
  dm.name = 'esp-ons';

  dm.setup = @(spp) setup(spp);
  dm.solve = @(data, t, X, Z) solve(data, t, X, Z);
end

function [data, setup] = setup(spp)
  expp = spp.private.expp;
  smax = spp.private.smax;
  rc = spp.private.rc;
  rd = spp.private.rd;

  data = struct();
  data.smax = smax;
  data.rc = rc;
  data.rd = rd;
  data.T = spp.T;

  minp = min(expp);
  maxp = max(expp);
  data.night = find(minp == expp);
  data.last_buy = data.T - ceil(smax / rd);
  last_fill = data.last_buy;
  while last_fill > 1
    i = mod(last_fill-1,24)+1;
    if expp(i) == maxp, break; end
    last_fill = last_fill-1;
  end
  data.last_fill = last_fill;

  setup = [];
end

function X = solve(data, t, X, Z)
  n = size(X,1);
  S = X(:,1) + X(:,2) - X(:,5) - X(:,6) + X(:,7);

  %% Z = [E D]
  E = Z(:,1);
  D = Z(:,2);

  fed = min(E, D);
  feg = E - fed;

  i = mod(t-1,24)+1;
  if t < data.last_buy
    if t < data.last_fill && ismember(i, data.night)
      fsd = zeros(n,1);
      fgs = min(data.smax-S, data.rc);
    else
      fsd = min(min(S, D-fed), data.rd);
      fgs = zeros(n,1);
    end
    fsg = zeros(n,1);
  else
    fsd = min(min(S, D-fed), data.rd);
    fsg = max(0, min(S-fsd, data.rd-fsd));
    fgs = zeros(n,1);
  end
  X = [S, zeros(n,1), fed, feg, fsd, fsg, fgs];
end
