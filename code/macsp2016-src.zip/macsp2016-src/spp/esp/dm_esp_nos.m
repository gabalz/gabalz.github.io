
function dm = dm_esp_nos()
%%% Decision maker for the energy problem with overnight storage refill.
%%%
  dm = struct();
  dm.name = 'esp-nos';

  dm.setup = @(spp) setup();
  dm.solve = @(data, t, X, Z) solve(data, t, X, Z);
end

function [data, setup] = setup()
  data = [];
  setup = [];
end

function X = solve(data, t, X, Z)
  S = X(:,1) + X(:,2) - X(:,5) - X(:,6) + X(:,7);
  %% Z = [E D]
  n = size(S,1);
  fed = min(Z, [], 2);
  feg = max(0, Z(:,1)-fed);
  X = [S zeros(n,1), fed, feg, zeros(n,3)];
end
