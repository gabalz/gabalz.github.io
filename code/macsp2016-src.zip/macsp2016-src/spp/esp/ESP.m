
function spp = ESP(sampleridx, varargin)
%%% Energy storage problem using a solar energy model with one battery.
%%%
  t1 = 1;
  if nargin >= 2
    arg = varargin{1};
    if ~isempty(arg), t1 = arg; end
  end

  T = 48;
  if nargin >= 3
    arg = varargin{2};
    if ~isempty(arg), T = arg; end
  end

  s1 = 0; % initial storage capacity
  smax = 20; % maximum storage capacity

  rc =  4; % maximum storage charge rate
  rd = 10; % maximum storage discharge rate

  Dmin = 0;
  Dmax = 15;

  Emin = 0;
  Emax = 12;

  p = struct();
  p.s1 = s1;
  p.rc = rc;
  p.rd = rd;
  p.smax = smax;
  p.Dmin = Dmin;
  p.Dmax = Dmax;
  p.Emin = Emin;
  p.Emax = Emax;
  p.sampleridx = sampleridx;

  %% hours:  0    1    2    3    4    5    6    7    8    9   10   11
  %%        12   13   14   15   16   17   18   19   20   21   22   23
  p.Dloc = [3.5, 2.5, 1.8, 1.5, 1.5, 2.0, 4.0, 5.5, 6.3, 6.4, 6.5, 6.4, ...
            6.3, 6.1, 6.0, 5.8, 5.7, 6.0, 6.8, 6.7, 6.4, 5.8, 5.0, 4.0]';
  p.Dscl = [1.0, 0.5, 0.5, 0.3, 0.3, 0.5, 1.0, 2.0, 2.0, 1.0, 1.0, 1.0, ...
            1.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 1.5, 1.5, 1.5, 1.0, 1.0]';
  p.Eloc = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.1, 2.3, 4.2, 5.8, 6.9, 7.8, ...
            8.3, 8.4, 8.1, 7.5, 6.5, 5.2, 3.2, 0.7, 0.0, 0.0, 0.0, 0.0]';
  p.Escl = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 2.0, 2.0, 2.0, 2.0, ...
            2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0]';
  p.expp = [11, 11, 11, 11, 11, 11, 22, 22, 22, 22, 22, 22, ...
            22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 11]';
  p.expw = [ 8,  8,  7,  7,  7,  9, 11, 18, 21, 21, 18, 18, ...
            18, 17, 17, 17, 17, 18, 21, 22, 19, 18, 11,  9]';

  distrD = @(t) trnormal(t, p.Dloc, p.Dscl, p.Dmin, p.Dmax);
  distrE = @(t) trnormal(t, p.Eloc, p.Escl, p.Emin, p.Emax);
  expPW = @(t) meanPW(t, p.expp, p.expw);

  dD1 = distrD(t1);
  d1 = dD1.mean; % initial demand

  dE1 = distrE(t1);
  e1 = dE1.mean; % initial energy production

  %%      1   2   3   4   5   6   7
  %% x = [s fes fed feg fsd fsg fgs], Z = [E D]
  FA = [1 0 0 0 0 1; ... % ... <= rc
        0 0 0 1 1 0; ... % ... <= rd
        1 1 1 0 0 0; ... % ... <= E
        0 1 0 1 0 0]';   % ... <= D
  fA = [1 0 0 -1 -1 1]';
  A = [-1 -fA';      ... % s + ... >= 0
        1  fA';      ... % s + ... <= smax
        zeros(4,1), FA'];
  b = [0; smax; rc; rd; nan; nan];
  lb = [nan; zeros(6,1)];
  ub = [nan; inf(6,1)];
  fXZ = @(t,X,Z) [getS(X) Z];
  fPP = @(t,XS1,X,Z) XS1;
  dynamics = @(t) esp_dynamics(A, b, lb, ub, fXZ, fPP);

  x0 = [s1; zeros(6,1)];
  z0 = [e1; d1];

  switch sampleridx
    case 1
      Xsampler = @(t, n, Xt, Zt, varargin) ...
                 esp_Xsampler1(s1, smax, Emax, Dmax, rc, rd, ...
                               t1, t, n, FA, fA, Zt);
    case 2
      Xsampler = @(t, n, Xt, Zt, varargin) ...
                 esp_Xsampler2(n, A, b, lb, ub, Xt, Zt, varargin{:});
    otherwise
      error(['Invalid sampleridx: ' num2str(sampleridx) '!']);
  end

  cost = @(t, Xt, Zt) esp_cost(expPW, t, Xt);
  Zsampler = @(t, n) esp_Zsampler(distrE, distrD, t, n);
  fixXSt = @(XS, X, Z, tol) fixXS(smax, rc, rd, XS, Z, tol);

  d = numel(lb);
  optdim = @(t) d;
  fixvar = @(t) [];

  spp = SPP('ESP', t1, T, x0, z0, cost, Xsampler, Zsampler, ...
            optdim, fixvar, dynamics, fixXSt);
  spp.private = p;
end

function S = getS(X)
  S = X(:,1) + X(:,2) - X(:,5) - X(:,6) + X(:,7);
end

function X = esp_Xsampler1(s1, smax, Emax, Dmax, rc, rd, ...
                           t1, t, n, FA, fA, Z)

  slimit = min(s1+rc*(t-t1), smax);
  S = rand(n,1)*slimit;

  E = max(Z(:,1));
  D = max(Z(:,2));

  Fub = [min(smax-S, min(E, rc)), ... % fes
         min(E, D).*ones(n,1),    ... % fed
         E.*ones(n,1),            ... % feg
         min(S, min(D, rd)),      ... % fsd
         min(S, rd),              ... % fsg
         min(smax-S, rc)];            % fgs

  Fb = [rc, rd, E, D];

  i = 1:n;
  F = rand(n,6) .* Fub;
  while true
    Fi = F(i,:);
    St1 = S(i) + Fi*fA;
    j = find(St1 < 0 | St1 > smax | max(bsxfun(@minus, Fi*FA, Fb) > 0, [], 2));
    if isempty(j), break; end
    i = i(j);
    F(i,:) = rand(numel(i),6) .* Fub(i,:);
  end
  X = [S F];
end

function X = esp_Xsampler2(n, A, b, lb, ub, Xt, Zt, bndrt, nchains, Xtgt)
  d = numel(lb);

  if nargin < 8
    bndrt = 0;
  end
  if nargin < 9
    nchains = 1;
  elseif ischar(nchains)
    nchains = eval(nchains);
  end
  if nargin < 10
    Xtgt = [];
  end

  nburn = d*d;
  nsolve = 10;

  %% enforce hard constraints for numerical stability
  Xt = max(0,Xt);
  Zt = max(0,Zt);

  S = getS(Xt);
  Smin = min(S);
  Smax = max(S);
  clear S;
  Emax = max(Zt(:,1));
  Dmax = max(Zt(:,2));

  lb(1) = Smin;
  ub(1) = Smax;
  b(5) = Emax;
  b(6) = Dmax;

  if ~isempty(Xtgt)
    Xrad = 0.5;
    lb = max(lb, min(Xtgt,[],1)'-Xrad);
    ub = min(max(Xtgt,[],1)'+Xrad, ub);
  end

  X = zeros(n,d);
  nsamples = 0;
  nsamplesi = ceil(n/nchains);
  prb = qcqp_create([], zeros(d,1), A, b, [], [], lb, ub);
  for i = 1:nchains
    x0 = zeros(d,1);
    for j = 1:nsolve
      f = randn(d,1);
      f = f / norm(f);
      prb = qcqp_update_f(prb, 1:d, f);
      [x0j, flag] = qcqp_solve(prb);
      if flag ~= 0
        error(['Solving LP failed: ' num2str(flag) '!']);
      end
      x0 = x0 + x0j/nsolve;
    end
    Xi = polysample(A, b, lb, ub, x0, nsamplesi, nburn, bndrt);

    ns = min(nsamplesi, n-nsamples);
    X(nsamples+[1:ns],:) = Xi(1:ns,:);
    nsamples = nsamples + ns;
  end
  assert (nsamples == n);
end

function [dim, A, b, Aeq, beq, lb, ub, fXZ, fPP, ...
          XZidxA, XZdimA, XZidxAeq, XZdimAeq, ...
          XZidxlb, XZdimlb, XZidxub, XZdimub] = ...
         esp_dynamics(A, b, lb, ub, fXZ, fPP)
  dim = numel(lb);
  Aeq = [];
  beq = [];
  XZidxA = [5 6]';
  XZdimA = [2 3]';
  XZidxAeq = [];
  XZdimAeq = [];
  XZidxlb = 1;
  XZdimlb = 1;
  XZidxub = 1;
  XZdimub = 1;
end

function pw = meanPW(t, expp, expw)
  i = mod(t-1,24)+1;
  pw = [expp(i); expw(i)];
end

function c = esp_cost(expPW, t, Xt)
  c = [Xt(:,7)-Xt(:,3)-Xt(:,5), -(Xt(:,4)+Xt(:,6))]*expPW(t);
end

function Z = esp_Zsampler(distrE, distrD, t, n)
  distrEt = distrE(t+1);
  distrDt = distrD(t+1);
  Z = [distrEt.sampler(n), distrDt.sampler(n)];
end

function X = fixXS(smax, rc, rd, X, Z, tol)
  X = max(0, X);
  S = X(:,1);
  F = X(:,2:end);

  ismodified = true;
  while ismodified
    ismodified = false;

    X = [S F];
    S1 = getS(X);

    i = find(S1 < 0);
    if ~isempty(i)
      ismodified = true;
      F(i,5) = F(i,5) + min(S1(i), -tol); % dec. fsg
      j = find(F(i,5) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,4) = F(ij,4) + F(ij,5); % dec. fsd
        F(ij,5) = 0;
      end
    end
    i = find(S1 > smax);
    if ~isempty(i)
      ismodified = true;
      F(i,6) = F(i,6) - max(S1(i)-smax, tol); % dec. fgs
      j = find(F(i,6) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,1) = F(ij,1) + F(ij,6); % dec. fes
        F(ij,6) = 0;
      end
    end

    Fc = F(:,1) + F(:,6) - rc; % fes + fgs <= rc
    i = find(Fc > 0);
    if ~isempty(i)
      ismodified = true;
      F(i,6) = F(i,6) - max(Fc(i), tol); % dec. fgs
      j = find(F(i,6) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,1) = F(ij,1) + F(ij,6);
        F(ij,6) = 0;
      end
    end

    Fd = F(:,4) + F(:,5) - rd; % fsd + fsg <= rd
    i = find(Fd > 0);
    if ~isempty(i)
      ismodified = true;
      F(i,5) = F(i,5) - max(Fd(i), tol); % dec. fsg
      j = find(F(i,5) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,4) = F(ij,4) + F(ij,5); % dec. fsd
        F(ij,5) = 0;
      end
    end

    FE = F(:,1) + F(:,2) + F(:,3) - Z(:,1); % fes + fed + feg <= E
    i = find(FE > 0);
    if ~isempty(i)
      ismodified = true;
      F(i,3) = F(i,3) - max(FE(i), tol); % dec. feg
      j = find(F(i,3) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,1) = F(ij,1) + F(ij,3); % dec. fes
        F(ij,3) = 0;

        j = find(F(ij,1) < 0);
        if ~isempty(j)
          ij = ij(j);
          F(ij,2) = F(ij,2) + F(ij,1); % dec. fed
          F(ij,1) = 0;
        end
      end
    end

    FD = F(:,2) + F(:,4) - Z(:,2); % fed + fsd <= D
    i = find(FD > 0);
    if ~isempty(i)
      ismodified = true;
      F(i,4) = F(i,4) - FD(i); % dec. fsd
      j = find(F(i,4) < 0);
      if ~isempty(j)
        ij = i(j);
        F(ij,2) = F(ij,2) + F(ij,4); % dec. fed
        F(ij,4) = 0;
      end
    end
  end
end

